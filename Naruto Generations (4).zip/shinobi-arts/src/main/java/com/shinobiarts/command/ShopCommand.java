package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.shinobiarts.Config;
import com.shinobiarts.shop.Shop;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

/** /shop: opens the ninja shop (see shop/Shop). */
public final class ShopCommand {
    private ShopCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shop").executes(ctx -> {
            if (!Config.b(Config.SHOP_ENABLED)) {
                ctx.getSource().sendFailure(Component.translatable("message.shinobiarts.shop_closed"));
                return 0;
            }
            Shop.open(ctx.getSource().getPlayerOrException());
            return 1;
        }));
    }
}
