package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.entity.FtgKunaiEntity;
import com.shinobiarts.fx.Fx;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModItems;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The Flying Thunder God Technique (Minato's space-time ninjutsu). A player marks places with the Flying Thunder God
 * kunai, then flashes to any mark in an instant:
 * <ul>
 *   <li><b>Seal</b>: right-click a block with the kunai to write the seal formula on it (sneak + right-click a seal of
 *       yours to wipe it off).</li>
 *   <li><b>Kunai</b>: a thrown kunai is a mark wherever it sticks. Flashing to it catches it again.</li>
 *   <li><b>Target</b>: anyone the kunai hits (thrown or in melee) carries the mark for a while; flashing to them puts
 *       you right behind them.</li>
 * </ul>
 * Teleport by right-clicking toward a mark with the kunai (it highlights when you aim at it) or from the Marks page
 * of the ninja menu. Anyone crouching right next to the user is taken along. Each player's marks are their own and
 * only they see their seals. No teleporting while in
 * combat (combat/CombatTag); marking still works.
 */
public final class FlyingThunderGod {
    private FlyingThunderGod() {}

    public enum MarkKind { SEAL, KUNAI, TARGET }

    /** How close (blocks) a crouching player has to be to be taken along. */
    private static final double CARRY_RANGE = 2.5;

    /** Longest name a player can give a mark. */
    public static final int MAX_LABEL = 32;

    /** One mark. Positions are where it was last seen (a kunai's or a target's may have moved since). */
    public static final class Mark {
        public int id;
        public MarkKind kind = MarkKind.SEAL;
        public String dim = "minecraft:overworld";
        public BlockPos pos = BlockPos.ZERO;
        public Direction face = Direction.UP;
        @Nullable
        public UUID uuid;
        public long expires;
        public String name = "";
        /** The name the player gave it on the Marks page (empty: none). */
        public String label = "";

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("Id", id);
            t.putString("MarkKind", kind.name());
            t.putString("Dim", dim);
            t.putLong("Pos", pos.asLong());
            t.putInt("Face", face.get3DDataValue());
            if (uuid != null) t.putUUID("Uuid", uuid);
            t.putLong("Expires", expires);
            t.putString("Name", name);
            if (!label.isEmpty()) t.putString("Label", label);
            return t;
        }

        static Mark load(CompoundTag t) {
            Mark m = new Mark();
            m.id = t.getInt("Id");
            try {
                m.kind = MarkKind.valueOf(t.getString("MarkKind"));
            } catch (IllegalArgumentException e) {
                m.kind = MarkKind.SEAL;
            }
            m.dim = t.getString("Dim");
            m.pos = BlockPos.of(t.getLong("Pos"));
            m.face = Direction.from3DDataValue(t.getInt("Face"));
            if (t.hasUUID("Uuid")) m.uuid = t.getUUID("Uuid");
            m.expires = t.getLong("Expires");
            m.name = t.getString("Name");
            m.label = t.getString("Label");
            return m;
        }

        /** The middle of the marked face of the block, or where the kunai / target was. */
        public Vec3 point() {
            if (kind != MarkKind.SEAL) return Vec3.atCenterOf(pos);
            return Vec3.atCenterOf(pos).add(face.getStepX() * 0.51, face.getStepY() * 0.51, face.getStepZ() * 0.51);
        }
    }

    /** A player's marks (saved with their ninja data and sent to their client). */
    public static final class Marks {
        public final List<Mark> list = new ArrayList<>();
        private int nextId = 1;

        @Nullable
        public Mark get(int id) {
            for (Mark m : list) if (m.id == id) return m;
            return null;
        }

        public CompoundTag save() {
            CompoundTag t = new CompoundTag();
            ListTag l = new ListTag();
            for (Mark m : list) l.add(m.save());
            t.put("List", l);
            t.putInt("Next", nextId);
            return t;
        }

        public void load(CompoundTag t) {
            list.clear();
            ListTag l = t.getList("List", Tag.TAG_COMPOUND);
            for (int i = 0; i < l.size(); i++) list.add(Mark.load(l.getCompound(i)));
            nextId = Math.max(1, t.getInt("Next"));
        }

        Mark add(ServerPlayer p, MarkKind kind) {
            int max = Config.i(Config.FTG_MAX_MARKS);
            while (list.size() >= max) {                       // the oldest mark goes
                Mark old = list.remove(0);
                p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_oldest_gone"), true);
                if (old.kind == MarkKind.KUNAI) forgetKunai(p, old);
            }
            Mark m = new Mark();
            m.id = nextId++;
            m.kind = kind;
            m.dim = p.level().dimension().location().toString();
            list.add(m);
            return m;
        }
    }

    // ---------------------------------------------------------------- who can use it

    public static boolean canUse(ServerPlayer p, NinjaData d, boolean tell) {
        Rank need = Rank.byId(Config.FTG_MIN_RANK.get().trim().toLowerCase());
        if (need != null && d.getRank().ordinal() < need.ordinal()) {
            if (tell) p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_rank", need.displayName())
                    .withStyle(ChatFormatting.RED), true);
            return false;
        }
        return true;
    }

    // ---------------------------------------------------------------- making marks

    /** Right-clicking a block with the kunai: write the seal on that face (sneaking: wipe off a seal of yours there). */
    public static void seal(ServerPlayer p, BlockPos pos, Direction face) {
        NinjaData d = NinjaData.get(p);
        if (d == null || !canUse(p, d, true)) return;
        String dim = p.level().dimension().location().toString();
        for (Mark m : d.ftg.list) {
            if (m.kind == MarkKind.SEAL && m.pos.equals(pos) && m.dim.equals(dim)) {
                if (p.isShiftKeyDown()) {
                    d.ftg.list.remove(m);
                    p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_removed"), true);
                    JutsuUtil.sound(p.level(), Vec3.atCenterOf(pos), SoundEvents.BOOK_PAGE_TURN, 0.8f, 0.8f);
                    ModNetwork.sync(p);
                } else {
                    p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_already"), true);
                }
                return;
            }
        }
        if (p.isShiftKeyDown()) return;
        Mark m = d.ftg.add(p, MarkKind.SEAL);
        m.pos = pos.immutable();
        m.face = face;
        m.name = p.level().getBlockState(pos).getBlock().getName().getString();
        p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_sealed", d.ftg.list.size(), Config.i(Config.FTG_MAX_MARKS))
                .withStyle(ChatFormatting.YELLOW), true);
        JutsuUtil.sound(p.level(), m.point(), SoundEvents.BOOK_PAGE_TURN, 1.0f, 1.2f);
        JutsuUtil.sound(p.level(), m.point(), SoundEvents.AMETHYST_BLOCK_CHIME, 0.6f, 1.6f);
        p.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
        ModNetwork.sync(p);
    }

    /** A thrown kunai stuck somewhere: it's a mark now (or the same mark, moved). */
    public static void kunaiLanded(FtgKunaiEntity kunai) {
        if (!(kunai.getOwner() instanceof ServerPlayer p)) return;
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        Mark m = null;
        for (Mark x : d.ftg.list) if (x.kind == MarkKind.KUNAI && kunai.getUUID().equals(x.uuid)) m = x;
        if (m == null) {
            m = d.ftg.add(p, MarkKind.KUNAI);
            m.uuid = kunai.getUUID();
            m.name = "";
        }
        m.dim = kunai.level().dimension().location().toString();
        m.pos = kunai.blockPosition();
        ModNetwork.sync(p);
    }

    /** A kunai of theirs was picked up or is gone: its mark goes with it. */
    public static void kunaiGone(FtgKunaiEntity kunai) {
        if (!(kunai.getOwner() instanceof ServerPlayer p)) return;
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        if (d.ftg.list.removeIf(m -> m.kind == MarkKind.KUNAI && kunai.getUUID().equals(m.uuid))) ModNetwork.sync(p);
    }

    /** The kunai struck someone: they carry the mark for a while. */
    public static void markTarget(ServerPlayer p, LivingEntity target) {
        NinjaData d = NinjaData.get(p);
        if (d == null || target == p || !canUse(p, d, false)) return;
        d.ftg.list.removeIf(m -> m.kind == MarkKind.TARGET && target.getUUID().equals(m.uuid));
        Mark m = d.ftg.add(p, MarkKind.TARGET);
        m.uuid = target.getUUID();
        m.pos = target.blockPosition();
        m.name = target.getName().getString();
        m.expires = p.level().getGameTime() + Config.i(Config.FTG_TARGET_SECONDS) * 20L;
        p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_marked", target.getDisplayName())
                .withStyle(ChatFormatting.YELLOW), true);
        ModNetwork.sync(p);
    }

    /** Every second: target marks that ran out go, and the others follow where their target is. */
    public static void tick(ServerPlayer p, NinjaData d) {
        if (d.ftg.list.isEmpty()) return;
        long now = p.level().getGameTime();
        boolean changed = d.ftg.list.removeIf(m -> m.kind == MarkKind.TARGET && m.expires < now);
        for (Mark m : d.ftg.list) {
            if (m.kind != MarkKind.TARGET || m.uuid == null) continue;
            Entity e = ((ServerLevel) p.level()).getEntity(m.uuid);
            if (e != null && e.isAlive() && e.level() == p.level()) {
                BlockPos at = e.blockPosition();
                if (!at.equals(m.pos)) {
                    m.pos = at;
                    changed = true;
                }
            } else if (e != null && !e.isAlive()) {
                m.expires = 0;
                changed = true;
            }
        }
        if (changed) {
            d.ftg.list.removeIf(m -> m.kind == MarkKind.TARGET && m.expires < now);
            ModNetwork.sync(p);
        }
    }

    // ---------------------------------------------------------------- the teleport

    /** The mark nearest the crosshair (within a few degrees, in range, in this dimension), if any. */
    @Nullable
    public static Mark aimed(ServerPlayer p, NinjaData d) {
        String dim = p.level().dimension().location().toString();
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle();
        double range = Config.i(Config.FTG_AIM_RANGE);
        Mark best = null;
        double bestCos = -2;
        for (Mark m : d.ftg.list) {
            if (!m.dim.equals(dim)) continue;
            Vec3 to = where(p.serverLevel(), m).subtract(eye);
            double dist = to.length();
            if (dist < 1.5 || dist > range) continue;
            // within 5 degrees, or within a block and a half of the line of sight when it's close
            double threshold = Math.min(Math.cos(Math.toRadians(5)), Math.cos(Math.atan2(1.6, dist)));
            double c = to.normalize().dot(look);
            if (c >= threshold && c > bestCos) {
                best = m;
                bestCos = c;
            }
        }
        return best;
    }

    /** Where a mark is now (a loaded kunai or target where it stands). */
    private static Vec3 where(ServerLevel level, Mark m) {
        if (m.kind != MarkKind.SEAL && m.uuid != null) {
            Entity e = level.getEntity(m.uuid);
            if (e != null) return m.kind == MarkKind.TARGET ? e.position().add(0, e.getBbHeight() * 0.6, 0) : e.position();
        }
        return m.point();
    }

    /** Flash to mark {@code id} (from the ninja menu). */
    public static void teleport(ServerPlayer p, int id) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        Mark m = d.ftg.get(id);
        if (m != null) teleport(p, d, m);
    }

    /** Removes mark {@code id} (from the ninja menu). */
    public static void remove(ServerPlayer p, int id) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        Mark m = d.ftg.get(id);
        if (m == null) return;
        d.ftg.list.remove(m);
        if (m.kind == MarkKind.KUNAI) forgetKunai(p, m);
        ModNetwork.sync(p);
    }

    /** Names mark {@code id} (from the ninja menu); an empty name gives it back its own. */
    public static void rename(ServerPlayer p, int id, String label) {
        NinjaData d = NinjaData.get(p);
        if (d == null) return;
        Mark m = d.ftg.get(id);
        if (m == null) return;
        String clean = label.replaceAll("[\\p{Cntrl}\u00A7]", "").trim();
        m.label = clean.length() > MAX_LABEL ? clean.substring(0, MAX_LABEL) : clean;
        ModNetwork.sync(p);
    }

    /** A kunai mark wiped from the menu: the kunai itself stays where it is, just unmarked. */
    private static void forgetKunai(ServerPlayer p, Mark m) {
        if (m.uuid == null) return;
        for (ServerLevel level : p.server.getAllLevels()) {
            if (level.getEntity(m.uuid) instanceof FtgKunaiEntity k) k.setUnmarked();
        }
    }

    public static boolean teleport(ServerPlayer p, NinjaData d, Mark m) {
        if (!canUse(p, d, true)) return false;
        ServerLevel here = p.serverLevel();
        long now = here.getGameTime();
        if (d.isInCombat(now)) {                                     // no flashing out of a fight
            p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_combat", (d.getCombatUntil() - now + 19) / 20)
                    .withStyle(ChatFormatting.RED), true);
            return false;
        }
        if (d.cooldownRemaining("flying_thunder_god", now) > 0) return false;
        ServerLevel there = p.server.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(m.dim)));
        if (there == null) {
            d.ftg.list.remove(m);
            ModNetwork.sync(p);
            return false;
        }
        if (there != here && !Config.b(Config.FTG_CROSS_DIMENSION)) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_other_dimension").withStyle(ChatFormatting.RED), true);
            return false;
        }
        float cost = d.maxChakra() * Config.f(Config.FTG_COST);
        if (d.getChakra() < cost) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra", (int) d.getChakra(), (int) Math.ceil(cost)).withStyle(ChatFormatting.RED), true);
            return false;
        }

        Vec3 spot;
        float yaw = p.getYRot(), pitch = p.getXRot();
        Entity entity = m.uuid != null ? there.getEntity(m.uuid) : null;
        switch (m.kind) {
            case TARGET -> {
                if (!(entity instanceof LivingEntity t) || !t.isAlive()) {
                    d.ftg.list.remove(m);
                    p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_faded").withStyle(ChatFormatting.GRAY), true);
                    ModNetwork.sync(p);
                    return false;
                }
                Vec3 facing = Vec3.directionFromRotation(0, t.getYRot());
                spot = t.position().subtract(facing.scale(t.getBbWidth() / 2 + 0.9));   // right behind them
                Vec3 to = t.getEyePosition().subtract(spot.add(0, p.getEyeHeight(), 0));
                yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
                pitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)));
            }
            case KUNAI -> spot = entity != null ? entity.position().subtract(0, 0.4, 0) : Vec3.atBottomCenterOf(m.pos);
            default -> {
                BlockPos out = m.pos.relative(m.face);
                spot = m.face == Direction.DOWN ? Vec3.atBottomCenterOf(out.below()) : Vec3.atBottomCenterOf(out);
            }
        }
        Vec3 safe = safeSpot(there, p, spot);
        if (safe == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.ftg_blocked").withStyle(ChatFormatting.RED), true);
            return false;
        }

        Vec3 from = p.position();
        // anyone crouching right next to you is taken along (not someone who's in combat)
        List<ServerPlayer> along = new ArrayList<>();
        for (ServerPlayer other : here.getEntitiesOfClass(ServerPlayer.class, p.getBoundingBox().inflate(CARRY_RANGE),
                o -> o != p && o.isAlive() && !o.isSpectator() && o.isShiftKeyDown() && o.distanceTo(p) <= CARRY_RANGE)) {
            NinjaData od = NinjaData.get(other);
            if (od != null && od.isInCombat(now)) continue;
            along.add(other);
        }
        d.consumeChakra(cost);
        d.setCooldown("flying_thunder_god", now + Config.i(Config.FTG_COOLDOWN));
        Fx.at(here, Fx.Visual.FLYING_THUNDER_GOD, from.add(0, 1, 0), 1f, 14);
        JutsuUtil.sound(here, from, SoundEvents.ENDERMAN_TELEPORT, 0.5f, 1.8f);
        p.stopRiding();
        if (there == here) {
            p.connection.teleport(safe.x, safe.y, safe.z, yaw, pitch);
        } else {
            p.teleportTo(there, safe.x, safe.y, safe.z, yaw, pitch);
        }
        p.setDeltaMovement(Vec3.ZERO);
        p.resetFallDistance();
        Fx.at(there, Fx.Visual.FLYING_THUNDER_GOD, safe.add(0, 1, 0), 1.3f + 0.3f * along.size(), 16);
        for (int i = 0; i < along.size(); i++) {                 // set down in a ring round you
            ServerPlayer other = along.get(i);
            double a = Math.toRadians(yaw) + Math.PI / 2 + i * (Math.PI * 2 / Math.max(3, along.size()));
            Vec3 near = safeSpot(there, other, safe.add(Math.cos(a) * 1.3, 0, Math.sin(a) * 1.3));
            if (near == null) near = safe;
            Fx.at(here, Fx.Visual.FLYING_THUNDER_GOD, other.position().add(0, 1, 0), 0.8f, 12);
            other.stopRiding();
            if (there == here) other.connection.teleport(near.x, near.y, near.z, other.getYRot(), other.getXRot());
            else other.teleportTo(there, near.x, near.y, near.z, other.getYRot(), other.getXRot());
            other.setDeltaMovement(Vec3.ZERO);
            other.resetFallDistance();
            other.displayClientMessage(Component.translatable("message.shinobiarts.ftg_taken", p.getDisplayName()).withStyle(ChatFormatting.YELLOW), true);
        }
        JutsuUtil.sound(there, safe, SoundEvents.ENDERMAN_TELEPORT, 0.6f, 1.5f);
        JutsuUtil.sound(there, safe, SoundEvents.TRIDENT_RETURN, 0.8f, 1.6f);
        if (m.kind == MarkKind.KUNAI) {                                // catch the kunai on arrival
            UUID uuid = m.uuid;
            d.ftg.list.remove(m);
            catchKunai(p, there, uuid, safe);
            Scheduler.later(2, () -> catchKunai(p, there, uuid, safe));
        }
        ModNetwork.sync(p);
        return true;
    }

    private static void catchKunai(ServerPlayer p, ServerLevel level, @Nullable UUID uuid, Vec3 near) {
        if (uuid == null) return;
        Entity e = level.getEntity(uuid);
        if (!(e instanceof FtgKunaiEntity k) || !k.isAlive()) return;
        if (!p.getAbilities().instabuild) {
            ItemStack stack = new ItemStack(ModItems.FLYING_THUNDER_GOD_KUNAI.get());
            if (!p.getInventory().add(stack)) p.drop(stack, false);
        }
        k.setUnmarked();
        k.discard();
    }

    /** A spot the player fits at, near {@code feet} in {@code level} (stepping up or down a little if needed). */
    @Nullable
    private static Vec3 safeSpot(Level level, ServerPlayer p, Vec3 feet) {
        double[] offsets = {0, 0.5, 1.0, -0.5, 1.5, -1.0, 2.0};
        double w = p.getBbWidth() / 2, h = p.getBbHeight();
        for (double dy : offsets) {
            Vec3 pos = feet.add(0, dy, 0);
            AABB box = new AABB(pos.x - w, pos.y, pos.z - w, pos.x + w, pos.y + h, pos.z + w);
            if (!level.noCollision(p, box)) continue;
            if (level.getFluidState(BlockPos.containing(pos)).is(FluidTags.LAVA)) continue;
            return pos;
        }
        return null;
    }
}
