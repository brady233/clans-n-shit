package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.entity.JutsuProjectile;
import com.shinobiarts.entity.SusanooEntity;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * The Susanoo: a giant of chakra summoned with the Mangekyou Sharingan. Key O summons it and grows it a stage at a time
 * (Ribcage, Skeletal, Humanoid, Armored, Perfect) as far as your level allows; Sneak + O releases it.
 * <ul>
 *   <li>It takes the hits meant for you (stage 1 lets 30% through, stage 2 15%) on its own health bar, so you take
 *       no knockback or fall damage while it stands. Sneaking blocks; hits in front do less (the Armored stage's
 *       shield, and the Perfect stage's wings from every side, much less). It heals once it hasn't been hit for a few
 *       seconds. At 0 it shatters and you can't summon it for 30 seconds.</li>
 *   <li>It costs chakra to summon and every second it stands; with too little left it fades.</li>
 *   <li>Amaterasu sets it alight (it burns a share of its health every second); the Kamui snap and Tsukuyomi go
 *       straight through to you. Sealed chakra, the eyes switching off or the Eight Gates end it.</li>
 *   <li>Left-click with an empty hand: a three-swing combo (from stage 2). Right-click with an empty hand: the special
 *       (ground slam, homing magatama, a chakra slash wave, a giant slash wave).</li>
 *   <li>The Humanoid and Armored Susanoo carry you in their chest (5.5 and 7.75 blocks up): it walks where you walk.
 *       The Perfect Susanoo carries you in its forehead crystal, 20 blocks up, and flies: you fly as usual and it goes
 *       where you go, never sinking below the ground.</li>
 *   <li>It builds itself up over a couple of seconds when summoned or when it grows ("formSeconds").</li>
 * </ul>
 * The entity itself (SusanooEntity) just follows: its position is set here every tick, and its health is the owner's.
 */
public final class Susanoo {
    public static final String[] NAMES = {"none", "ribcage", "skeletal", "humanoid", "armored", "perfect"};
    /** The Perfect Susanoo carries its owner with their feet this high above its own, this far forward. */
    public static final double RIDE_HEIGHT = 20.0, RIDE_FORWARD = 0.25;
    /** The Humanoid and Armored Susanoo carry their owner in the chest, feet this high above its own. */
    public static final double CHEST_HUMANOID = 5.5, CHEST_ARMORED = 7.75;

    /** How high a stage carries its owner above its feet: on the ground (Ribcage, Skeletal), the chest, or the head. */
    public static double rideHeight(int stage) {
        return switch (stage) {
            case 3 -> CHEST_HUMANOID;
            case 4 -> CHEST_ARMORED;
            case 5 -> RIDE_HEIGHT;
            default -> 0.0;
        };
    }

    /** The Humanoid and Armored stages hold their owner at a fixed height in the chest (the Perfect one flies). */
    public static boolean holdsInChest(int stage) {
        return stage == 3 || stage == 4;
    }
    private static final int[] SPECIAL_HIT = {0, 0, 12, 9, 12, 14};
    private static final Map<UUID, SusanooEntity> ENTITIES = new HashMap<>();
    private static final Map<UUID, Float> LAST_HIT_AMOUNT = new HashMap<>();
    private static final ThreadLocal<Boolean> PASS_THROUGH = ThreadLocal.withInitial(() -> false);

    private enum End { RELEASED, SHATTERED, NO_CHAKRA, EYES_OFF, SEALED, SILENT }

    private Susanoo() {}

    // ================================================================ rules

    /** Level needed for a stage (1-5). */
    public static int levelFor(int stage) {
        return (int) Config.stage(Config.SUSANOO_LEVELS, stage, 100);
    }

    /** The highest stage this ninja can reach right now (0 = none yet). */
    public static int highestStage(NinjaData d) {
        if (d.getSharinganStage() < Dojutsu.MANGEKYOU) return 0;
        int best = 0;
        for (int s = 1; s <= 5; s++) {
            if (d.getLevel() < levelFor(s)) break;
            if (s == 5 && Config.b(Config.SUSANOO_PERFECT_NEEDS_ETERNAL) && d.getMangekyouDesign() != MangekyouDesign.ETERNAL) break;
            best = s;
        }
        return best;
    }

    public static boolean mangekyouOn(NinjaData d) {
        return d.isMangekyouActive();
    }

    /** Health of a stage (Ribcage 1000 ... Perfect 11000 by default; optionally growing with max chakra). */
    public static float maxHealth(NinjaData d, int stage) {
        double base = Config.stage(Config.SUSANOO_HEALTH, stage, 1000);
        if (!Config.b(Config.SUSANOO_HEALTH_SCALES)) return (float) base;
        return (float) (base * (0.5 + 0.5 * d.maxChakra() / 100.0));
    }

    public static Component stageName(int stage) {
        return Component.translatable("susanoo.shinobiarts." + NAMES[Math.max(0, Math.min(5, stage))]);
    }

    private static void say(ServerPlayer p, String key, ChatFormatting color, Object... args) {
        p.displayClientMessage(Component.translatable("message.shinobiarts." + key, args).withStyle(color), true);
    }

    private static int[] rgb(int c) {
        return new int[]{(c >> 16) & 255, (c >> 8) & 255, c & 255};
    }

    private static DustParticleOptions dust(int color, float size) {
        int[] c = rgb(color);
        return new DustParticleOptions(new Vector3f(c[0] / 255f, c[1] / 255f, c[2] / 255f), size);
    }

    // ================================================================ key O

    public static void key(ServerPlayer p, NinjaData d, boolean sneaking) {
        int stage = d.getSusanooStage();
        if (sneaking) {
            if (stage > 0) end(p, d, End.RELEASED);
            return;
        }
        if (!Afflictions.canAct(p)) return;
        if (!mangekyouOn(d)) {
            say(p, d.getSharinganStage() >= Dojutsu.MANGEKYOU ? "susanoo_eyes_off" : "susanoo_need_mangekyou", ChatFormatting.RED);
            return;
        }
        if (d.getGatesOpen() > 0) {
            say(p, "susanoo_gates", ChatFormatting.RED);
            return;
        }
        long now = p.level().getGameTime();
        long cd = d.cooldownRemaining("susanoo", now);
        if (stage == 0 && cd > 0) {
            say(p, "susanoo_cooldown", ChatFormatting.GRAY, String.format("%.0f", Math.ceil(cd / 20.0)));
            return;
        }
        int top = highestStage(d);
        int next = stage + 1;
        if (next > 5) {
            say(p, "susanoo_full", ChatFormatting.GOLD);
            return;
        }
        if (next > top) {
            if (next == 5 && d.getLevel() >= levelFor(5)) say(p, "susanoo_need_eternal", ChatFormatting.RED);
            else say(p, "susanoo_need_level", ChatFormatting.RED, stageName(next), levelFor(next));
            return;
        }
        float cost = (float) Config.stage(Config.SUSANOO_SUMMON_COST, next, 0.1) * d.maxChakra();
        if (!p.isCreative() && d.getChakra() < cost) {
            say(p, "not_enough_chakra", ChatFormatting.RED, (int) d.getChakra(), (int) Math.ceil(cost));
            return;
        }
        double lift = rideHeight(next) - rideHeight(stage);
        if (lift > 0 && !p.level().noCollision(p, p.getBoundingBox().move(0, lift, 0))) {
            say(p, "susanoo_no_room", ChatFormatting.RED);
            return;
        }
        if (!p.isCreative()) d.consumeChakra(cost);
        summon(p, d, next);
    }

    private static void summon(ServerPlayer p, NinjaData d, int stage) {
        int old = d.getSusanooStage();
        float frac = old > 0 && d.getSusanooMaxHp() > 0 ? d.getSusanooHp() / d.getSusanooMaxHp() : 1f;
        float max = maxHealth(d, stage);
        d.setSusanooMaxHp(max);
        d.setSusanooHp(Math.max(1, max * frac));
        d.setSusanooStage(stage);
        if (old == 0) d.setSusanooLastHit(0);
        SusanooEntity e = entity(p, d, true);
        if (e != null) e.setStage(stage);
        if (rideHeight(stage) != rideHeight(old)) enterRide(p, d, old, stage);
        ServerLevel level = p.serverLevel();
        int chakra = colorsFor(d)[4];
        float h = (float) (stage == 5 ? 24 : 4 + stage * 2.5);
        Vec3 base = e != null ? e.position() : p.position();
        level.sendParticles(dust(chakra, 3.0f), base.x, base.y + h * 0.5, base.z, 120 + stage * 40, 1 + stage * 0.6, h * 0.35, 1 + stage * 0.6, 0.0);
        level.sendParticles(ParticleTypes.END_ROD, base.x, base.y + 1, base.z, 30, 1.5, 0.3, 1.5, 0.15);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 2.0f, 0.5f + stage * 0.08f);
        level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.PLAYERS, 1.2f, 0.6f);
        say(p, "susanoo_stage", ChatFormatting.LIGHT_PURPLE, stageName(stage));
        ModNetwork.sync(p);
    }

    /** Ends it: released (Sneak + O), shattered, out of chakra, eyes off, sealed. */
    private static void end(ServerPlayer p, NinjaData d, End why) {
        int stage = d.getSusanooStage();
        if (stage == 0) return;
        SusanooEntity e = ENTITIES.remove(p.getUUID());
        ServerLevel level = p.serverLevel();
        int chakra = colorsFor(d)[4];
        if (e != null) {
            float h = e.getBbHeight();
            level.sendParticles(dust(chakra, 3.0f), e.getX(), e.getY() + h * 0.5, e.getZ(), 150, e.getBbWidth() * 0.4, h * 0.35, e.getBbWidth() * 0.4, 0.0);
            if (why == End.SHATTERED) {
                level.sendParticles(ParticleTypes.END_ROD, e.getX(), e.getY() + h * 0.5, e.getZ(), 80, e.getBbWidth() * 0.4, h * 0.3, e.getBbWidth() * 0.4, 0.25);
            }
            e.discard();
        }
        if (rideHeight(stage) > 0) leaveHead(p, d, rideHeight(stage));
        d.setSusanooStage(0);
        d.setSusanooBurnUntil(0);
        LAST_HIT_AMOUNT.remove(p.getUUID());
        long now = p.level().getGameTime();
        int cd = why == End.SHATTERED ? Config.i(Config.SUSANOO_SHATTER_COOLDOWN) : Config.i(Config.SUSANOO_DISSOLVE_COOLDOWN);
        d.setCooldown("susanoo", now + cd * 20L);
        switch (why) {
            case SHATTERED -> {
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 2.0f, 0.5f);
                level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 2.0f, 0.4f);
                say(p, "susanoo_shattered", ChatFormatting.RED, Config.i(Config.SUSANOO_SHATTER_COOLDOWN));
            }
            case NO_CHAKRA -> say(p, "susanoo_no_chakra", ChatFormatting.GRAY);
            case EYES_OFF -> say(p, "susanoo_faded_eyes", ChatFormatting.GRAY);
            case SEALED -> say(p, "susanoo_faded_sealed", ChatFormatting.DARK_PURPLE);
            default -> {
            }
        }
        if (why != End.SHATTERED && why != End.SILENT) {
            level.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.5f, 0.6f);
        }
        ModNetwork.sync(p);
    }

    /** Ends it without a cooldown or messages (logging out, dying, changing dimension). */
    public static void endQuietly(ServerPlayer p) {
        NinjaData d = NinjaData.get(p);
        if (d != null && d.getSusanooStage() > 0) {
            end(p, d, End.SILENT);
            d.setCooldown("susanoo", 0);
        }
        SusanooEntity e = ENTITIES.remove(p.getUUID());
        if (e != null) e.discard();
    }

    public static void clearAll() {
        ENTITIES.clear();
        LAST_HIT_AMOUNT.clear();
    }

    // ================================================================ the entity

    @Nullable
    private static SusanooEntity entity(ServerPlayer p, NinjaData d, boolean create) {
        SusanooEntity e = ENTITIES.get(p.getUUID());
        if (e != null && (e.isRemoved() || e.level() != p.level())) {
            e.discard();
            ENTITIES.remove(p.getUUID());
            e = null;
        }
        if (e == null && create) {
            e = new SusanooEntity(ModEntities.SUSANOO.get(), p.level());
            e.setOwner(p);
            e.setStage(Math.max(1, d.getSusanooStage()));
            e.setColors(colorsFor(d));
            place(p, d, e);
            p.level().addFreshEntity(e);
            ENTITIES.put(p.getUUID(), e);
        }
        return e;
    }

    @Nullable
    public static SusanooEntity entityOf(ServerPlayer p) {
        SusanooEntity e = ENTITIES.get(p.getUUID());
        return e == null || e.isRemoved() ? null : e;
    }

    /**
     * Where it stands: on its owner (Ribcage, Skeletal), right below them (Humanoid, Armored: they're in its chest), or
     * below and just behind them (Perfect: they're in its head).
     */
    public static Vec3 feetFor(net.minecraft.world.entity.player.Player p, int stage, Vec3 ownerPos, float yaw) {
        if (stage < 3) return ownerPos;
        if (stage < 5) return new Vec3(ownerPos.x, ownerPos.y - rideHeight(stage), ownerPos.z);
        Vec3 f = Vec3.directionFromRotation(0, yaw);
        return new Vec3(ownerPos.x - f.x * RIDE_FORWARD, ownerPos.y - RIDE_HEIGHT, ownerPos.z - f.z * RIDE_FORWARD);
    }

    private static void place(ServerPlayer p, NinjaData d, SusanooEntity e) {
        int stage = d.getSusanooStage();
        float yaw = stage == 5 ? p.getYRot() : p.yBodyRot;
        Vec3 at = feetFor(p, stage, p.position(), yaw);
        e.moveTo(at.x, at.y, at.z, yaw, 0);
    }

    // ================================================================ every tick (from NinjaTicker)

    public static void tick(ServerPlayer p, NinjaData d) {
        int stage = d.getSusanooStage();
        if (stage == 0) {
            SusanooEntity e = ENTITIES.remove(p.getUUID());
            if (e != null) e.discard();
            if (d.susanooGaveFlight()) restoreFlight(p, d);
            return;
        }
        if (!p.isAlive() || p.isSpectator()) {
            endQuietly(p);
            return;
        }
        if (!mangekyouOn(d)) {
            end(p, d, End.EYES_OFF);
            return;
        }
        if (Afflictions.isSealed(p)) {
            end(p, d, End.SEALED);
            return;
        }
        SusanooEntity e = entity(p, d, true);
        if (e == null) return;
        if (e.getStage() != stage) e.setStage(stage);
        e.setColors(colorsFor(d));
        e.setDesign(d.getMangekyouDesign());
        place(p, d, e);
        e.setBlocking(isBlocking(p, d));
        p.fallDistance = 0;
        if (rideHeight(stage) > 0) holdInHead(p, d, stage);
        if (p.tickCount % 20 == 0) everySecond(p, d, stage, e);
    }

    private static void everySecond(ServerPlayer p, NinjaData d, int stage, SusanooEntity e) {
        long now = p.level().getGameTime();
        float max = d.getSusanooMaxHp();
        if (!p.isCreative()) {
            float drain = (float) Config.stage(Config.SUSANOO_DRAIN, stage, 0.02) * d.maxChakra();
            if (d.getChakra() < drain) {
                end(p, d, End.NO_CHAKRA);
                return;
            }
            d.consumeChakra(drain);
        }
        boolean changed = false;
        if (d.getSusanooBurnUntil() > now) {              // Amaterasu eats into it
            d.setSusanooHp(d.getSusanooHp() - Config.f(Config.SUSANOO_AMATERASU_BURN) * max);
            p.serverLevel().sendParticles(new DustParticleOptions(new Vector3f(0.08f, 0f, 0.1f), 3.0f), e.getX(), e.getY() + e.getBbHeight() * 0.4,
                    e.getZ(), 60, e.getBbWidth() * 0.4, e.getBbHeight() * 0.3, e.getBbWidth() * 0.4, 0.0);
            changed = true;
            if (d.getSusanooHp() <= 0) {
                end(p, d, End.SHATTERED);
                return;
            }
        } else if (d.getSusanooHp() < max && now - d.getSusanooLastHit() >= Config.i(Config.SUSANOO_REGEN_DELAY) * 20L) {
            float cost = Config.f(Config.SUSANOO_REGEN_COST) * d.maxChakra();
            if (p.isCreative() || d.getChakra() >= cost) {
                if (!p.isCreative()) d.consumeChakra(cost);
                d.setSusanooHp(Math.min(max, d.getSusanooHp() + Config.f(Config.SUSANOO_REGEN) * max));
                changed = true;
            }
        }
        if (changed) ModNetwork.sync(p);
    }

    // ---------------------------------------------------------------- the Perfect Susanoo's head

    /** Lifts (or lowers) the owner into the new stage's chest or head as it grows. */
    private static void enterRide(ServerPlayer p, NinjaData d, int from, int to) {
        double lift = rideHeight(to) - rideHeight(from);
        p.connection.teleport(p.getX(), p.getY() + lift, p.getZ(), p.getYRot(), p.getXRot());
        holdInHead(p, d, to);
        // walking pace in the chest; the Perfect Susanoo flies faster
        p.getAbilities().setFlyingSpeed(to == 5 ? 0.09f : 0.03f);
        p.onUpdateAbilities();
    }

    private static void holdInHead(ServerPlayer p, NinjaData d, int stage) {
        boolean update = false;
        if (!p.getAbilities().mayfly) {
            p.getAbilities().mayfly = true;
            d.setSusanooGaveFlight(true);
            update = true;
        }
        if (!p.getAbilities().flying) {
            p.getAbilities().flying = true;
            update = true;
        }
        if (update) p.onUpdateAbilities();
        // its feet never sink into the ground: lift the rider if they do (the client does this smoothly too); in the
        // chest stages it walks on the ground, so the rider stays at chest height
        double h = rideHeight(stage);
        double ground = groundBelow(p.level(), p.getX(), p.getY() - h + 1.5, p.getZ());
        boolean off = holdsInChest(stage) ? Math.abs(p.getY() - h - ground) > 2.5 : p.getY() - h < ground - 2;
        if (off) p.connection.teleport(p.getX(), ground + h, p.getZ(), p.getYRot(), p.getXRot());
    }

    /** Top of the highest solid block at or below {@code y} (searching 48 blocks down), or y - 48. */
    public static double groundBelow(Level level, double x, double y, double z) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int top = (int) Math.floor(y);
        for (int by = top; by > top - 48; by--) {
            pos.set(Math.floor(x), by, Math.floor(z));
            BlockState s = level.getBlockState(pos);
            if (!s.getCollisionShape(level, pos).isEmpty()) return by + 1;
        }
        return top - 48;
    }

    private static void leaveHead(ServerPlayer p, NinjaData d, double height) {
        double ground = groundBelow(p.level(), p.getX(), p.getY(), p.getZ());
        p.connection.teleport(p.getX(), Math.max(ground, p.getY() - height - 4), p.getZ(), p.getYRot(), p.getXRot());
        p.fallDistance = 0;
        d.setFallProtectUntil(p.level().getGameTime() + 100);
        p.getAbilities().setFlyingSpeed(0.05f);
        if (p.isCreative()) p.onUpdateAbilities();
        restoreFlight(p, d);
    }

    private static void restoreFlight(ServerPlayer p, NinjaData d) {
        boolean gave = d.susanooGaveFlight();
        d.setSusanooGaveFlight(false);
        p.getAbilities().setFlyingSpeed(0.05f);
        if (gave && !p.isCreative() && !p.isSpectator()) {
            p.getAbilities().mayfly = false;
            p.getAbilities().flying = false;
        }
        p.onUpdateAbilities();
    }

    // ================================================================ taking hits

    private static boolean isBlocking(ServerPlayer p, NinjaData d) {
        if (!p.isShiftKeyDown()) return false;
        if (d.getSusanooStage() < 5) return true;              // in the chest stages Sneak just blocks
        double ground = groundBelow(p.level(), p.getX(), p.getY() - RIDE_HEIGHT + 1.5, p.getZ());
        return p.getY() - RIDE_HEIGHT <= ground + 0.6; // in the air, Sneak just flies down
    }

    /** Damage types the Susanoo can't stop: hunger, drowning, the void, /kill, poison and magic, Kamui, Tsukuyomi. */
    private static boolean bypasses(DamageSource src) {
        return src.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || src.is(DamageTypes.STARVE) || src.is(DamageTypes.DROWN)
                || src.is(DamageTypes.IN_WALL) || src.is(DamageTypes.MAGIC) || src.is(DamageTypes.INDIRECT_MAGIC)
                || src.is(DamageTypes.WITHER) || src.is(ModDamage.KAMUI) || src.is(ModDamage.TSUKUYOMI);
    }

    /**
     * A hit on the owner (LivingAttackEvent): the Susanoo takes its share. Returns true if the original hit should be
     * cancelled (any share the Susanoo doesn't take is dealt to the owner again here).
     */
    public static boolean redirect(ServerPlayer p, DamageSource src, float amount) {
        if (PASS_THROUGH.get()) return false;
        NinjaData d = NinjaData.get(p);
        if (d == null || d.getSusanooStage() == 0 || bypasses(src)) return false;
        if (src.is(DamageTypeTags.IS_FALL)) return true;
        long now = p.level().getGameTime();
        if (src.is(ModDamage.AMATERASU)) {                 // the black flames catch on the Susanoo instead
            d.setSusanooBurnUntil(now + 60);
            return true;
        }
        int stage = d.getSusanooStage();
        float share = (float) Config.stage(Config.SUSANOO_ABSORB, stage, 1.0);
        damage(p, d, src, amount * share);
        float rest = amount * (1 - share);
        if (rest > 0.01f && p.isAlive()) {
            PASS_THROUGH.set(true);
            try {
                p.hurt(src, rest);
            } finally {
                PASS_THROUGH.set(false);
            }
        }
        if (stage == 1 && src.getEntity() instanceof LivingEntity attacker && src.getDirectEntity() == attacker && attacker != p) {
            attacker.knockback(1.2, p.getX() - attacker.getX(), p.getZ() - attacker.getZ()); // the ribcage shoves them off
            attacker.hurtMarked = true;
        }
        return true;
    }

    /** Someone hit the Susanoo's own body. */
    public static boolean hitSusanoo(ServerPlayer owner, DamageSource src, float amount) {
        NinjaData d = NinjaData.get(owner);
        if (d == null || d.getSusanooStage() == 0) return false;
        if (src.is(ModDamage.AMATERASU)) {
            d.setSusanooBurnUntil(owner.level().getGameTime() + 60);
            return true;
        }
        if (bypasses(src)) return false;
        damage(owner, d, src, amount);
        return true;
    }

    private static void damage(ServerPlayer p, NinjaData d, DamageSource src, float amount) {
        long now = p.level().getGameTime();
        // like a creature's hurt time: a second hit within half a second only counts for what it adds
        float last = LAST_HIT_AMOUNT.getOrDefault(p.getUUID(), 0f);
        if (now - d.getSusanooLastHit() < 10) {
            if (amount <= last) return;
            float extra = amount - last;
            LAST_HIT_AMOUNT.put(p.getUUID(), amount);
            amount = extra;
        } else {
            LAST_HIT_AMOUNT.put(p.getUUID(), amount);
            d.setSusanooLastHit(now);
        }
        amount *= 1 - blockReduction(p, d, src);
        if (amount <= 0) return;
        d.setSusanooHp(d.getSusanooHp() - amount);
        SusanooEntity e = entityOf(p);
        if (e != null) {
            Vec3 at = src.getSourcePosition() != null ? src.getSourcePosition() : e.position().add(0, e.getBbHeight() * 0.5, 0);
            p.serverLevel().sendParticles(dust(colorsFor(d)[4], 2.0f), at.x, at.y, at.z, 12, 0.4, 0.4, 0.4, 0.0);
            p.serverLevel().playSound(null, e.getX(), e.getY() + 1, e.getZ(), SoundEvents.AMETHYST_BLOCK_HIT, SoundSource.PLAYERS, 1.2f, 0.6f);
        }
        if (d.getSusanooHp() <= 0) end(p, d, End.SHATTERED);
        else ModNetwork.sync(p);
    }

    private static float blockReduction(ServerPlayer p, NinjaData d, DamageSource src) {
        SusanooEntity e = entityOf(p);
        if (e == null || !e.isBlocking()) return 0f;
        int stage = d.getSusanooStage();
        if (stage == 5) return Config.f(Config.SUSANOO_BLOCK_WINGS);
        Vec3 from = src.getSourcePosition();
        if (from == null) return 0f;
        Vec3 to = from.subtract(p.position());
        Vec3 look = Vec3.directionFromRotation(0, p.getYRot());
        double len = Math.hypot(to.x, to.z);
        if (len < 1e-3 || (to.x * look.x + to.z * look.z) / len < 0.2) return 0f;   // not in front
        return stage == 4 ? Config.f(Config.SUSANOO_BLOCK_SHIELD) : Config.f(Config.SUSANOO_BLOCK_FRONT);
    }

    // ================================================================ attacks

    /** Left-click (empty hand): the next swing of the three-hit combo. */
    public static void attack(ServerPlayer p, NinjaData d) {
        int stage = d.getSusanooStage();
        if (stage < 2 || !Afflictions.canAct(p)) return;
        SusanooEntity e = entityOf(p);
        if (e == null || e.isBlocking()) return;
        long now = p.level().getGameTime();
        if (now - d.getSusanooLastSwing() < 8) return;
        int combo = now - d.getSusanooLastSwing() > 30 ? 0 : d.getSusanooCombo() % 3;
        d.setSusanooCombo(combo + 1);
        d.setSusanooLastSwing(now);
        e.playAction((byte) (SusanooEntity.SWING_1 + combo));
        float damage = (float) Config.stage(Config.SUSANOO_COMBO_DAMAGE, stage, 10) * (combo == 2 ? 1.5f : 1f) * Config.f(Config.DAMAGE_MULTIPLIER)
                + d.stat(Stat.KENJUTSU) * Config.f(Config.KENJUTSU_PER_POINT);
        double reach = Config.stage(Config.SUSANOO_REACH, stage, 6);
        Scheduler.later(combo == 2 ? 9 : 7, () -> sweep(p, stage, damage, reach, combo == 2));
    }

    private static void sweep(ServerPlayer p, int stage, float damage, double reach, boolean finisher) {
        NinjaData d = NinjaData.get(p);
        SusanooEntity e = entityOf(p);
        if (d == null || e == null || d.getSusanooStage() != stage) return;
        ServerLevel level = p.serverLevel();
        Vec3 feet = e.position();
        float yaw = stage == 5 ? p.getYRot() : p.yBodyRot;
        Vec3 fwd = Vec3.directionFromRotation(0, yaw);
        double cosArc = stage == 5 ? Math.cos(Math.toRadians(80)) : Math.cos(Math.toRadians(finisher ? 50 : 70));
        double top = e.getBbHeight() + 1;
        int hits = 0;
        for (LivingEntity t : level.getEntitiesOfClass(LivingEntity.class, e.getBoundingBox().inflate(reach + 2, 2, reach + 2),
                c -> JutsuUtil.isValidTarget(p, c))) {
            Vec3 to = t.position().subtract(feet);
            double flat = Math.hypot(to.x, to.z);
            if (flat > reach + t.getBbWidth() / 2 || to.y < -3 || to.y > top) continue;
            if (flat > 1.0 && (to.x * fwd.x + to.z * fwd.z) / flat < cosArc) continue;
            t.invulnerableTime = 0;
            t.hurt(p.damageSources().playerAttack(p), damage);
            Vec3 push = flat > 1e-3 ? new Vec3(to.x / flat, 0, to.z / flat) : fwd;
            JutsuUtil.push(t, push.scale(finisher ? 1.1 : 0.6).add(0, finisher ? 0.45 : 0.25, 0));
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, t.getX(), t.getY() + t.getBbHeight() * 0.6, t.getZ(), 1, 0, 0, 0, 0);
            hits++;
        }
        // the arc of the swing, in chakra light
        DustParticleOptions arc = dust(colorsFor(d)[4], 2.2f);
        double y = feet.y + (stage == 5 ? 8 : e.getBbHeight() * 0.45);
        for (int i = -10; i <= 10; i++) {
            double a = Math.toRadians(yaw) + i * (stage == 5 ? 0.14 : 0.12);
            double r = reach * 0.85;
            level.sendParticles(arc, feet.x - Math.sin(a) * r, y + (finisher ? (10 - Math.abs(i)) * 0.15 : 0), feet.z + Math.cos(a) * r, 2, 0.15, 0.15, 0.15, 0.0);
        }
        level.playSound(null, feet.x, feet.y + 2, feet.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.6f, 0.5f);
        if (hits > 0 && finisher) level.playSound(null, feet.x, feet.y + 2, feet.z, SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS, 1.6f, 0.6f);
    }

    /** Right-click (empty hand): the stage's special. */
    public static void special(ServerPlayer p, NinjaData d) {
        int stage = d.getSusanooStage();
        if (stage < 2 || !Afflictions.canAct(p)) return;
        SusanooEntity e = entityOf(p);
        if (e == null || e.isBlocking()) return;
        long now = p.level().getGameTime();
        long cd = d.cooldownRemaining("susanoo_special", now);
        if (cd > 0) {
            say(p, "susanoo_special_cooldown", ChatFormatting.GRAY, String.format("%.1f", cd / 20.0));
            return;
        }
        float cost = (float) Config.stage(Config.SUSANOO_SPECIAL_COST, stage, 0.05) * d.maxChakra();
        if (!p.isCreative() && d.getChakra() < cost) {
            say(p, "not_enough_chakra", ChatFormatting.RED, (int) d.getChakra(), (int) Math.ceil(cost));
            return;
        }
        if (!p.isCreative()) d.consumeChakra(cost);
        d.setCooldown("susanoo_special", now + (long) (Config.stage(Config.SUSANOO_SPECIAL_COOLDOWN, stage, 8) * 20));
        e.playAction(SusanooEntity.SPECIAL);
        float damage = (float) Config.stage(Config.SUSANOO_SPECIAL_DAMAGE, stage, 20) * Config.f(Config.DAMAGE_MULTIPLIER);
        if (stage >= 4) damage += d.stat(Stat.KENJUTSU) * Config.f(Config.KENJUTSU_PER_POINT);
        float dmg = damage;
        // each Mangekyou's own: Sasuke looses an arrow from his bow, Obito throws his Kamui shuriken; Itachi and
        // Madara throw the magatama (Humanoid) or cut a wave of chakra (Armored, Perfect)
        MangekyouDesign design = d.getMangekyouDesign();
        int hit = SPECIAL_HIT[Math.max(2, Math.min(5, stage))];
        if (stage == 2) Scheduler.later(hit, () -> slam(p, dmg));
        else if (design == MangekyouDesign.SASUKE) Scheduler.later(hit, () -> arrow(p, stage, dmg));
        else if (design.hasKamui()) Scheduler.later(hit, () -> kamuiShuriken(p, stage));
        else if (stage == 3) Scheduler.later(hit, () -> magatama(p, dmg));
        else if (stage == 4) Scheduler.later(hit, () -> slashWave(p, 4, dmg, 30, 5, 4));
        else Scheduler.later(hit, () -> slashWave(p, 5, dmg, 50, 16, 9));
        ModNetwork.sync(p);
    }

    private static boolean stillAt(ServerPlayer p, int stage) {
        NinjaData d = NinjaData.get(p);
        return p.isAlive() && d != null && d.getSusanooStage() == stage && entityOf(p) != null;
    }

    /** Skeletal: both arms come down on the ground in front; everything around is hit and thrown up. */
    private static void slam(ServerPlayer p, float damage) {
        if (!stillAt(p, 2)) return;
        ServerLevel level = p.serverLevel();
        Vec3 fwd = Vec3.directionFromRotation(0, p.yBodyRot);
        Vec3 c = p.position().add(fwd.scale(3));
        BlockPos below = BlockPos.containing(c.x, c.y - 0.5, c.z);
        BlockState ground = level.getBlockState(below);
        if (!ground.isAir()) level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, ground), c.x, c.y + 0.2, c.z, 120, 2.0, 0.2, 2.0, 0.2);
        level.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y + 0.5, c.z, 3, 1.0, 0.2, 1.0, 0);
        for (LivingEntity t : JutsuUtil.inRadius(level, p, c.add(0, 1, 0), 4)) {
            t.hurt(ModDamage.jutsu(level, null, p), damage);
            JutsuUtil.push(t, new Vec3(0, 0.8, 0));
        }
        breakBlocks(p, level, below, 2, 1);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2f, 0.7f);
        level.playSound(null, c.x, c.y, c.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0f, 0.5f);
    }

    /** Humanoid: three magatama of chakra from its left hand, each curving into a target. */
    private static void magatama(ServerPlayer p, float damage) {
        if (!stillAt(p, 3)) return;
        NinjaData d = NinjaData.get(p);
        int color = d == null ? 0x8A55FF : colorsFor(d)[4];
        LivingEntity target = JutsuUtil.rayTarget(p, 48);
        float yaw = p.getYRot();
        Vec3 left = Vec3.directionFromRotation(0, yaw - 90);
        SusanooEntity body = entityOf(p);                     // its hand, measured from its own feet (you ride in its chest)
        Vec3 hand = (body != null ? body.position() : p.position()).add(0, 6.5, 0).add(left.scale(-2.5));
        for (int i = 0; i < 3; i++) {
            int k = i;
            Scheduler.later(i * 3, () -> {
                if (!stillAt(p, 3)) return;
                Vec3 dir = Vec3.directionFromRotation(p.getXRot(), p.getYRot() + (k - 1) * 12);
                JutsuProjectile.magatama(p, hand, dir, damage, color, target);
                p.serverLevel().playSound(null, hand.x, hand.y, hand.z, SoundEvents.ILLUSIONER_CAST_SPELL, SoundSource.PLAYERS, 1.2f, 1.2f + k * 0.1f);
            });
        }
    }

    /**
     * Sasuke's Susanoo: an arrow of chakra loosed from the great bow, curving onto what you look at and bursting there.
     * Bigger with each stage.
     */
    private static void arrow(ServerPlayer p, int stage, float damage) {
        if (!stillAt(p, stage)) return;
        NinjaData d = NinjaData.get(p);
        int color = d == null ? 0x8A55FF : colorsFor(d)[4];
        LivingEntity target = JutsuUtil.rayTarget(p, 80);
        SusanooEntity body = entityOf(p);
        double up = stage == 5 ? 14 : stage == 4 ? 7 : 5;
        Vec3 from = (body != null ? body.position() : p.position()).add(0, up, 0).add(Vec3.directionFromRotation(0, p.getYRot()).scale(stage == 5 ? 6 : 3));
        Vec3 aim = target != null ? target.getBoundingBox().getCenter() : p.getEyePosition().add(p.getLookAngle().scale(64));
        float scale = stage == 5 ? 3.5f : stage == 4 ? 2.2f : 1.6f;
        com.shinobiarts.entity.JutsuProjectile.susanooArrow(p, from, aim.subtract(from).normalize(), damage, color, scale, target);
        ServerLevel level = p.serverLevel();
        level.playSound(null, from.x, from.y, from.z, SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 3.0f, 0.5f);
        level.playSound(null, from.x, from.y, from.z, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.5f, 1.8f);
    }

    /**
     * Obito's Perfect Susanoo: it hurls a Kamui shuriken from each hand, one after the other, curving in on what you
     * look at. A hit warps away a share of the target's health (JutsuProjectile.kamuiShare).
     */
    /** Which hand throws the next Kamui shuriken (they alternate, one per press). */
    private static final java.util.Map<java.util.UUID, Boolean> NEXT_HAND = new java.util.HashMap<>();

    private static void kamuiShuriken(ServerPlayer p, int stage) {
        if (!stillAt(p, stage)) return;
        LivingEntity target = JutsuUtil.rayTarget(p, 64);
        SusanooEntity body = entityOf(p);
        double up = stage == 5 ? 13 : stage == 4 ? 6 : 4.5, out = stage == 5 ? 6 : stage == 4 ? 3 : 2.2;
        Vec3 base = (body != null ? body.position() : p.position()).add(0, up, 0);
        boolean right = NEXT_HAND.getOrDefault(p.getUUID(), true);
        NEXT_HAND.put(p.getUUID(), !right);
        // thrown from one hand, straight where you aim (curving in on a creature if you aim at one)
        Vec3 side = Vec3.directionFromRotation(0, p.getYRot() + (right ? 90 : -90));
        Vec3 hand = base.add(side.scale(out)).add(Vec3.directionFromRotation(0, p.getYRot()).scale(out * 0.5));
        Vec3 aim = target != null ? target.getBoundingBox().getCenter() : JutsuUtil.aimAnywhere(p, 64);
        Vec3 dir = aim.subtract(hand).normalize();
        com.shinobiarts.entity.JutsuProjectile.kamuiShuriken(p, hand, dir, target);
        ServerLevel level = p.serverLevel();
        level.playSound(null, hand.x, hand.y, hand.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 2.0f, 0.4f);
        level.playSound(null, hand.x, hand.y, hand.z, SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 2.0f, 0.5f);
    }


    /**
     * Armored / Perfect: a crescent of chakra flies out from the blade, {@code range} blocks forward at 2 blocks a
     * tick. It goes through creatures (hitting each once) and walls.
     */
    private static void slashWave(ServerPlayer p, int stage, float damage, double range, double width, double height) {
        if (!stillAt(p, stage)) return;
        NinjaData d = NinjaData.get(p);
        SusanooEntity e = entityOf(p);
        if (d == null || e == null) return;
        ServerLevel level = p.serverLevel();
        float yaw = stage == 5 ? p.getYRot() : p.yBodyRot;
        Vec3 fwd = Vec3.directionFromRotation(0, yaw);
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        Vec3 origin = e.position().add(0, 1, 0);
        DustParticleOptions glow = dust(colorsFor(d)[4], 3.0f);
        Set<Integer> struck = new HashSet<>();
        int steps = (int) Math.ceil(range / 2.0);
        level.playSound(null, origin.x, origin.y + 2, origin.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 2.0f, 0.4f);
        level.playSound(null, origin.x, origin.y + 2, origin.z, SoundEvents.TRIDENT_RIPTIDE_3, SoundSource.PLAYERS, 1.5f, stage == 5 ? 0.5f : 0.8f);
        Scheduler.repeat(0, 1, steps, i -> {
            double dist = (i + 1) * 2.0;
            Vec3 c = origin.add(fwd.scale(dist));
            for (int k = -8; k <= 8; k++) {             // the crescent: bowed forward in the middle
                double f = k / 8.0;
                Vec3 at = c.add(right.scale(f * width / 2)).add(fwd.scale((1 - f * f) * 1.5));
                level.sendParticles(glow, at.x, at.y + height * 0.5, at.z, 3, 0.1, height * 0.3, 0.1, 0.0);
            }
            if (i % 2 == 0) level.sendParticles(ParticleTypes.SWEEP_ATTACK, c.x, c.y + height * 0.5, c.z, 2, width * 0.2, height * 0.2, width * 0.2, 0);
            for (LivingEntity t : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(c, c).inflate(width / 2 + 2, height + 2, width / 2 + 2),
                    t -> JutsuUtil.isValidTarget(p, t) && !struck.contains(t.getId()))) {
                Vec3 to = t.position().subtract(origin);
                double along = to.x * fwd.x + to.z * fwd.z, side = to.x * right.x + to.z * right.z;
                if (along < dist - 2.5 || along > dist + 1.5 || Math.abs(side) > width / 2 + t.getBbWidth() / 2 || to.y < -2 || to.y > height + 1) continue;
                struck.add(t.getId());
                t.invulnerableTime = 0;
                t.hurt(ModDamage.jutsu(level, null, p), damage);
                JutsuUtil.push(t, fwd.scale(0.9).add(0, 0.3, 0));
            }
            if (i % 2 == 0) breakBlocks(p, level, BlockPos.containing(c.x, c.y + height * 0.5, c.z), (int) Math.ceil(width / 2), (int) Math.ceil(height / 2));
        });
    }

    /** Breaks blocks around a spot, only when the config allows (and jutsu griefing is on). */
    private static void breakBlocks(ServerPlayer p, ServerLevel level, BlockPos center, int rx, int ry) {
        if (!Config.b(Config.SUSANOO_BREAK_BLOCKS) || !JutsuUtil.griefing(level, p)) return;
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-rx, -ry, -rx), center.offset(rx, ry, rx))) {
            BlockState s = level.getBlockState(pos);
            float hardness = s.getDestroySpeed(level, pos);
            if (s.isAir() || hardness < 0 || hardness > 50 || level.getBlockEntity(pos) != null) continue;
            level.destroyBlock(pos, false, p);
        }
    }

    // ================================================================ colours (/susanoo color)

    /** Named colours for /susanoo color: body and armour shades. */
    public static final Map<String, int[]> PRESETS = new java.util.LinkedHashMap<>();

    static {
        PRESETS.put("purple", new int[]{0x8A55FF, 0x6B3BE6});
        PRESETS.put("blue", new int[]{0x3F6DFF, 0x2B4BD6});
        PRESETS.put("light_blue", new int[]{0x7FC4FF, 0x5AA6F0});
        PRESETS.put("red", new int[]{0xFF4848, 0xD42A2A});
        PRESETS.put("green", new int[]{0x45D66A, 0x2FAE4F});
        PRESETS.put("yellow", new int[]{0xFFE04A, 0xE0B92A});
        PRESETS.put("orange", new int[]{0xFF9A3C, 0xE0761F});
        PRESETS.put("white", new int[]{0xF2F2FF, 0xC9C9E6});
        PRESETS.put("cyan", new int[]{0x3FF0F0, 0x22C4CC});
        PRESETS.put("pink", new int[]{0xFF7AD9, 0xE254B8});
    }

    /** All six colours from a preset: weapons a lighter shade of the body (as in the show), white eyes, the flames in the body colour. */
    public static int[] presetColors(String name) {
        int[] p = PRESETS.get(name);
        if (p == null) return null;
        int c = p[0];
        int light = (((((c >> 16) & 255) + 255) / 2) << 16) | (((((c >> 8) & 255) + 255) / 2) << 8) | (((c & 255) + 255) / 2);
        return new int[]{p[0], p[1], light, 0xFFFFFF, p[0], p[0]};
    }

    /**
     * The colours it's drawn in: the player's own (/susanoo color), or, while they've never picked any, its Mangekyou's
     * colours from the show: Itachi's red, Sasuke's purple, Obito's cyan, Madara's blue.
     */
    public static int[] colorsFor(NinjaData d) {
        int[] mine = d.getSusanooColors();
        if (!java.util.Arrays.equals(mine, NinjaData.defaultSusanooColors())) return mine;
        // body, armour, weapons, eyes, chakra (the flames), aura: weapons glow in the Susanoo's own colour, as in the show
        return switch (d.getMangekyouDesign()) {
            case ITACHI -> new int[]{0xFF5A3A, 0xE0402A, 0xFF9A6A, 0xFFFFFF, 0xFF6A3A, 0xFF7A48};    // the Totsuka and Yata, red-orange
            case OBITO -> new int[]{0x4FC4FF, 0x2E8AE0, 0x9AE0FF, 0xFFFFFF, 0x4FC4FF, 0x6AD2FF};
            case ETERNAL -> new int[]{0x3F6DFF, 0x2B4BD6, 0x8AA6FF, 0xFFFFFF, 0x3F6DFF, 0x5A84FF};   // Madara's blue blades
            default -> new int[]{0x8A55FF, 0x6B3BE6, 0xB98CFF, 0xFFFFFF, 0x8A55FF, 0x9A66FF};       // Sasuke's purple bow and sword
        };
    }

    public static void applyColors(ServerPlayer p) {
        NinjaData d = NinjaData.get(p);
        SusanooEntity e = entityOf(p);
        if (d != null && e != null) e.setColors(colorsFor(d));
    }
}
