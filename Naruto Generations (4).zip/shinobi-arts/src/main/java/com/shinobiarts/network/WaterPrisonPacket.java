package com.shinobiarts.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> client: a Water Prison sphere of {@code radius} around {@code targetId}, held by {@code casterId}, for
 * {@code ticks} ticks (0 = it burst). Drawn by client/WaterPrisonRender.
 */
public class WaterPrisonPacket {
    private final int casterId;
    private final int targetId;
    private final int ticks;
    private final float radius;

    public WaterPrisonPacket(int casterId, int targetId, int ticks, float radius) {
        this.casterId = casterId;
        this.targetId = targetId;
        this.ticks = ticks;
        this.radius = radius;
    }

    public WaterPrisonPacket(FriendlyByteBuf buf) {
        this.casterId = buf.readVarInt();
        this.targetId = buf.readVarInt();
        this.ticks = buf.readVarInt();
        this.radius = buf.readFloat();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(casterId);
        buf.writeVarInt(targetId);
        buf.writeVarInt(ticks);
        buf.writeFloat(radius);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.shinobiarts.client.WaterPrisonRender.set(casterId, targetId, ticks, radius));
    }
}
