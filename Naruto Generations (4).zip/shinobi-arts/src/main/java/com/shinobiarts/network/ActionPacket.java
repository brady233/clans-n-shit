package com.shinobiarts.network;

import com.shinobiarts.jutsu.ServerActions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Client -> server: the player pressed a key or a menu button. It only carries the request;
 * the server checks everything (chakra, cooldowns, points, Ryo) before doing anything.
 */
public class ActionPacket {
    public static final int CAST = 0;
    public static final int NEXT = 1;
    public static final int PREV = 2;
    public static final int DOJUTSU = 4;
    public static final int CHARGE_START = 5;
    public static final int CHARGE_STOP = 6;
    public static final int NINJA_JUMP = 7;
    public static final int SAGE_MODE = 8;
    /** arg = stat ordinal, arg2 = points to add. */
    public static final int ALLOCATE_STAT = 9;
    public static final int RESET_STATS = 10;
    /** arg = coin ordinal, or -1 for every coin. */
    public static final int DEPOSIT = 11;
    /** arg = coin ordinal, arg2 = number of coins. */
    public static final int WITHDRAW = 12;
    /** The stats menu's "Leave team" button. */
    public static final int TEAM_LEAVE = 13;
    /** The Jutsu page's "Upgrade" button; arg = the jutsu's index (Jutsus.index). */
    public static final int UPGRADE_JUTSU = 14;
    /** A Jutsu key (eye techniques); arg = 1-3, arg2 = 1 if sneaking. */
    public static final int EYE_JUTSU = 15;
    /** A Jutsu key came up (Kamui is held); arg = 1-3. */
    public static final int EYE_JUTSU_RELEASE = 16;
    /** The Substitution key: auto-dodge on/off. */
    public static final int SUBSTITUTION_TOGGLE = 17;
    /** The Chakra Control key: tree climbing and water walking on/off. */
    public static final int CHAKRA_CONTROL = 18;
    /** The Eight Gates key: open the next gate; arg2 = 1 if sneaking (close them all). */
    public static final int EIGHT_GATES = 19;
    /** Susanoo key: summon / grow a stage (arg2 = 1: Sneak held, release it). */
    public static final int SUSANOO = 20;
    /** Left-click with an empty hand inside a Susanoo: the next combo swing. */
    public static final int SUSANOO_ATTACK = 21;
    /** Right-click with an empty hand inside a Susanoo: its special. */
    public static final int SUSANOO_SPECIAL = 22;
    /** Left-click at the air with a formed Rasenshuriken: throw it. */
    public static final int THROW_RASENSHURIKEN = 23;
    /** The local player started (arg 1) or stopped (arg 0) hanging from a ceiling. */
    public static final int CEILING = 24;
    /** Right-click at the Eighth Gate: Night Guy. */
    public static final int NIGHT_GUY = 25;
    /** Right-click came up while holding Water Prison (the client says so, in case the item use was never started). */
    public static final int HOLD_RELEASED = 26;
    /** The Tailed Beast key (rage form, or the chakra cloak on and off). */
    public static final int TAILED_BEAST = 27;
    // 28: unused
    /** A Tailed Beast Bomb (right-click in the chakra cloak). */
    public static final int BEAST_BOMB = 29;
    /** Flying Thunder God from the ninja menu: teleport to mark {@code arg}. */
    public static final int FTG_TELEPORT = 30;
    /** Flying Thunder God from the ninja menu: wipe out mark {@code arg}. */
    public static final int FTG_REMOVE = 31;
    /** The Bounties page opened: send the bounty board. */
    public static final int BOUNTY_BOARD = 32;

    private final int action;
    private final int arg;
    private final int arg2;

    public ActionPacket(int action) {
        this(action, 0, 0);
    }

    public ActionPacket(int action, int arg, int arg2) {
        this.action = action;
        this.arg = arg;
        this.arg2 = arg2;
    }

    public ActionPacket(FriendlyByteBuf buf) {
        this.action = buf.readVarInt();
        this.arg = buf.readVarInt();
        this.arg2 = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(action);
        buf.writeVarInt(arg);
        buf.writeVarInt(arg2);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) ServerActions.handle(player, action, arg, arg2);
    }
}
