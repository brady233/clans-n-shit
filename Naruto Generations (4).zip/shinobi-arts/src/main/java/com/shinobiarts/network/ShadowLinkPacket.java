package com.shinobiarts.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Server -> client: Shadow Possession's shadow, stretched along the ground from the caster to the creature it holds,
 * for {@code ticks} ticks (0 = it let go). Drawn by client/ShadowLinkRender.
 */
public class ShadowLinkPacket {
    private final int casterId;
    private final int targetId;
    private final int ticks;

    public ShadowLinkPacket(int casterId, int targetId, int ticks) {
        this.casterId = casterId;
        this.targetId = targetId;
        this.ticks = ticks;
    }

    public ShadowLinkPacket(FriendlyByteBuf buf) {
        this.casterId = buf.readVarInt();
        this.targetId = buf.readVarInt();
        this.ticks = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(casterId);
        buf.writeVarInt(targetId);
        buf.writeVarInt(ticks);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.shinobiarts.client.ShadowLinkRender.set(casterId, targetId, ticks));
    }
}
