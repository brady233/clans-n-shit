package com.shinobiarts.event;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.KekkeiGenkai;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

/**
 * DNA drops ("Spawn weights and chances.toml"): DNA of any nature or kekkei genkai and kekkei genkai jutsu scrolls
 * from the mobs listed there, and a defeated player's own DNA (one of their natures or kekkei genkai).
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DropEvents {
    private DropEvents() {}

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        LivingEntity dead = event.getEntity();
        if (dead.level().isClientSide || !(event.getSource().getEntity() instanceof ServerPlayer killer) || killer == dead) return;
        RandomSource random = dead.getRandom();

        if (dead instanceof ServerPlayer victim) {
            NinjaData vd = NinjaData.get(victim);
            if (vd == null || random.nextDouble() >= Config.d(Config.PLAYER_DNA_CHANCE)) return;
            List<Item> owned = new ArrayList<>();
            for (KekkeiGenkai kg : KekkeiGenkai.owned(vd)) owned.add(ModItems.DNA.get(kg).get());
            for (ChakraNature n : ChakraNature.NATURES) {
                if (vd.hasNature(n)) owned.add(ModItems.NATURE_DNA.get(n).get());
            }
            if (!owned.isEmpty()) drop(event, dead, new ItemStack(owned.get(random.nextInt(owned.size()))));
            return;
        }

        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(dead.getType());
        String key = id == null ? "" : id.toString();
        boolean hostile = dead instanceof Enemy;
        if (random.nextDouble() < chance(Config.strings(Config.DNA_DROPS), key, hostile)) {
            List<RegistryObject<Item>> all = ModItems.allDna();
            drop(event, dead, new ItemStack(all.get(random.nextInt(all.size())).get()));
        }
    }

    /** The chance listed for this mob ("minecraft:zombie=0.05"), or for "*" if it's hostile and not listed itself. */
    static double chance(List<String> entries, String mob, boolean hostile) {
        double wildcard = 0;
        for (String e : entries) {
            int eq = e.indexOf('=');
            if (eq <= 0) continue;
            String name = e.substring(0, eq).trim();
            double value;
            try {
                value = Double.parseDouble(e.substring(eq + 1).trim());
            } catch (NumberFormatException ex) {
                continue;
            }
            if (name.equals(mob)) return value;
            if (name.equals("*") && hostile) wildcard = value;
        }
        return wildcard;
    }

    private static void drop(LivingDropsEvent event, LivingEntity dead, ItemStack stack) {
        ItemEntity item = new ItemEntity(dead.level(), dead.getX(), dead.getY() + 0.5, dead.getZ(), stack);
        item.setDefaultPickUpDelay();
        event.getDrops().add(item);
    }
}
