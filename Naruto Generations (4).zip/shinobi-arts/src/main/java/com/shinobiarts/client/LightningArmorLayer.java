package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Lightning Armor: a crackling shell of blue sparks around the body (textures/entity/lightning_armor.png, scrolling
 * like a charged creeper's glow) while the jutsu is up. Everyone nearby sees it.
 */
public class LightningArmorLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/lightning_armor.png");
    private final HumanoidModel<T> shell;

    public LightningArmorLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.shell = new HumanoidModel<>(models.bakeLayer(ClientSetup.LIGHTNING_ARMOR_LAYER));
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if ((ClientEyes.look(entity) & SharinganManager.LOOK_LIGHTNING) == 0 || entity.isInvisible()) return;
        getParentModel().copyPropertiesTo(shell);
        shell.setAllVisible(true);
        float t = entity.tickCount + partialTick;
        VertexConsumer consumer = buffer.getBuffer(RenderType.energySwirl(TEXTURE, (t * 0.02f) % 1f, (t * 0.013f) % 1f));
        shell.renderToBuffer(poseStack, consumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 0.9f, 0.95f, 1f, 1f);
        // arcs of lightning crawling over the body, new ones every tick
        org.joml.Vector3f camL = new org.joml.Matrix4f(poseStack.last().pose()).invert().transformPosition(new org.joml.Vector3f());
        net.minecraft.world.phys.Vec3 cam = new net.minecraft.world.phys.Vec3(camL.x(), camL.y(), camL.z());
        net.minecraft.util.RandomSource r = net.minecraft.util.RandomSource.create(entity.getId() * 9973L + entity.tickCount * 31L);
        for (int k = 0; k < 6; k++) {
            net.minecraft.world.phys.Vec3 a = onBody(r), b = onBody(r);
            if (a.distanceToSqr(b) < 0.09) continue;
            com.shinobiarts.client.fx.FxDraw.bolt(buffer, poseStack, cam, a, b, r.nextLong(), 0.1f, 0.025f, 0x9CD2FF, 0.9f, 1);
        }
    }

    /** A random point just outside the body (model space: y runs down from the head's top to the feet). */
    private static net.minecraft.world.phys.Vec3 onBody(net.minecraft.util.RandomSource r) {
        double y = -0.45 + r.nextDouble() * 1.9;
        double a = r.nextDouble() * Math.PI * 2;
        double w = y < 0 ? 0.32 : y < 0.75 ? 0.42 : 0.26;
        return new net.minecraft.world.phys.Vec3(Math.cos(a) * w, y, Math.sin(a) * w * 0.6);
    }
}
