package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.shinobiarts.entity.FtgKunaiEntity;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** A thrown Flying Thunder God kunai: its own model, tip first along its flight, and stuck tip-in where it lands. */
public class FtgKunaiRenderer extends EntityRenderer<FtgKunaiEntity> {
    private final ItemRenderer itemRenderer;
    private ItemStack stack = ItemStack.EMPTY;

    public FtgKunaiRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(FtgKunaiEntity entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int light) {
        if (entity.tickCount < 2 && this.entityRenderDispatcher.camera.getEntity().distanceToSqr(entity) < 12.25) return;
        if (stack.isEmpty()) stack = new ItemStack(ModItems.FLYING_THUNDER_GOD_KUNAI.get());
        poseStack.pushPose();
        // Same orientation maths as arrows: afterwards +X points along the flight direction.
        poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTicks, entity.yRotO, entity.getYRot()) - 90.0f));
        poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partialTicks, entity.xRotO, entity.getXRot())));
        poseStack.mulPose(Axis.ZP.rotationDegrees(-45f));        // the model points diagonally, like an item sprite
        poseStack.translate(-0.12, -0.12, 0);                    // tip a little into what it's stuck in
        poseStack.scale(0.6f, 0.6f, 0.6f);
        this.itemRenderer.renderStatic(stack, ItemDisplayContext.NONE, light, OverlayTexture.NO_OVERLAY, poseStack, buffer,
                entity.level(), entity.getId());
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, light);
    }

    @Override
    public ResourceLocation getTextureLocation(FtgKunaiEntity entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
