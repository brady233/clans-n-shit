package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.client.fx.FxDraw;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/**
 * Jutsu that change the body, drawn on whoever has them up (everyone sees them, from the look bits):
 * <ul>
 *   <li>Rock Armor: the body sheathed in plates of grey stone with dark cracks between them.</li>
 *   <li>Dance of the Willow: bone blades jutting from the forearms, elbows, shoulders and spine.</li>
 *   <li>Vitality Surge: the Strength of a Hundred seal, a violet diamond on the forehead with black lines spreading
 *       over the face and body.</li>
 * </ul>
 */
public final class BodyJutsuLayers {
    private BodyJutsuLayers() {}

    public static final ResourceLocation ROCK = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/rock_armor.png");
    public static final ResourceLocation SEAL = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/byakugou.png");

    /** Rock Armor's stone shell. */
    public static class RockLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
        private final HumanoidModel<AbstractClientPlayer> shell;

        public RockLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
            super(parent);
            this.shell = new HumanoidModel<>(models.bakeLayer(ClientSetup.ROCK_ARMOR_LAYER));
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing, float limbAmount,
                           float partial, float age, float headYaw, float headPitch) {
            if ((ClientEyes.look(p) & SharinganManager.LOOK_ROCK) == 0 || p.isInvisible()) return;
            getParentModel().copyPropertiesTo(shell);
            shell.setAllVisible(true);
            shell.hat.visible = false;
            shell.renderToBuffer(ps, buffers.getBuffer(RenderType.entityCutoutNoCull(ROCK)), light, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
        }
    }

    /** Dance of the Willow's bone blades. */
    public static class BoneLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
        public BoneLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
            super(parent);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing, float limbAmount,
                           float partial, float age, float headYaw, float headPitch) {
            if ((ClientEyes.look(p) & SharinganManager.LOOK_BONE) == 0 || p.isInvisible()) return;
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            VertexConsumer vc = FxDraw.blocks(buffers);
            FxDraw.Paint bone = FxDraw.block("minecraft:block/bone_block_side", 0xFFFFFF, 1f);
            // model space: 1 = a block, y points down, the front is -z; arms hang from their shoulder pivot
            arm(ps, vc, m.rightArm, -1, bone, light);
            arm(ps, vc, m.leftArm, 1, bone, light);
            ps.pushPose();
            m.body.translateAndRotate(ps);
            for (int i = 0; i < 4; i++) {                    // the spine
                Vec3 base = new Vec3(0, (1.5 + i * 2.6) / 16, 2.1 / 16);
                FxDraw.cone(vc, ps, base, base.add(0, -0.08, 0.3 - i * 0.03), 0.05f, 6, bone, light);
            }
            for (int s = -1; s <= 1; s += 2) {               // the shoulders
                Vec3 base = new Vec3(s * 3.2 / 16, 0.3 / 16, 1.0 / 16);
                FxDraw.cone(vc, ps, base, base.add(s * 0.08, -0.32, 0.18), 0.06f, 6, bone, light);
            }
            ps.popPose();
        }

        private static void arm(PoseStack ps, VertexConsumer vc, ModelPart part, int side, FxDraw.Paint bone, int light) {
            ps.pushPose();
            part.translateAndRotate(ps);
            float outer = side < 0 ? -3.05f / 16 : 3.05f / 16;
            for (int i = 0; i < 3; i++) {                    // blades along the outside of the forearm, swept back
                Vec3 base = new Vec3(outer, (5.2 + i * 1.6) / 16, 0.6 / 16);
                FxDraw.cone(vc, ps, base, base.add(side * 0.22, 0.1, 0.24), 0.045f, 6, bone, light);
            }
            Vec3 elbow = new Vec3(side < 0 ? -1f / 16 : 1f / 16, 4.2 / 16, 2.05 / 16);
            FxDraw.cone(vc, ps, elbow, elbow.add(0, -0.05, 0.42), 0.06f, 6, bone, light);
            ps.popPose();
        }
    }

    /** Vitality Surge's seal marks. */
    public static class SealLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
        private final HumanoidModel<AbstractClientPlayer> skin;

        public SealLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent, EntityModelSet models) {
            super(parent);
            this.skin = new HumanoidModel<>(models.bakeLayer(ClientSetup.SEAL_MARKS_LAYER));
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing, float limbAmount,
                           float partial, float age, float headYaw, float headPitch) {
            if ((ClientEyes.look(p) & SharinganManager.LOOK_SEAL) == 0 || p.isInvisible()) return;
            getParentModel().copyPropertiesTo(skin);
            skin.setAllVisible(true);
            skin.renderToBuffer(ps, buffers.getBuffer(RenderType.entityTranslucent(SEAL)), light, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
        }
    }
}
