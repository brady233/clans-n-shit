package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.JutsuProjectile;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * The Water Dragon: a translucent dragon of pale water. Its body is the path it has flown, so it pours up out of the
 * ground where it was cast and snakes along behind the head, tapering to the tail, with fins down its back; the head
 * has a long snout, open jaws with teeth, swept-back horns and glowing eyes.
 */
public final class WaterDragonRender {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/jutsu/water_dragon.png");
    private static final int RING = 10;
    private static final double STEP = 0.4;

    /** Where each dragon's head has been (newest first), kept only while the dragon exists. */
    private static final Map<JutsuProjectile, ArrayDeque<Vec3>> TRAILS = new WeakHashMap<>();

    private WaterDragonRender() {}

    public static void render(JutsuProjectile dragon, float partial, PoseStack ps, MultiBufferSource buffers, int packedLight) {
        Vec3 head = dragon.getPosition(partial);
        float time = dragon.tickCount + partial;
        float scale = dragon.getScale();
        double bodyLen = 16.0 * scale;

        ArrayDeque<Vec3> trail = TRAILS.computeIfAbsent(dragon, k -> new ArrayDeque<>());
        if (trail.isEmpty() || trail.peekFirst().distanceToSqr(head) > 0.09) trail.addFirst(head);

        // the path from the head back, up to one body length
        List<Vec3> pts = new ArrayList<>();
        pts.add(head);
        double len = 0;
        Vec3 prev = head;
        int used = 0;
        for (Vec3 p : trail) {
            used++;
            double d = p.distanceTo(prev);
            if (d < 1e-3) continue;
            len += d;
            pts.add(p);
            prev = p;
            if (len >= bodyLen) break;
        }
        while (trail.size() > used + 2) trail.pollLast();
        if (pts.size() < 2) {
            Vec3 v = dragon.getDeltaMovement();
            Vec3 back = v.lengthSqr() > 1e-6 ? v.normalize().scale(-0.5) : new Vec3(0, -0.5, 0);
            pts.add(head.add(back));
            len = 0.5;
        }

        // even samples along it
        List<Vec3> s = new ArrayList<>();
        List<Double> arc = new ArrayList<>();
        s.add(pts.get(0));
        arc.add(0.0);
        double acc = 0, want = STEP;
        for (int i = 0; i + 1 < pts.size(); i++) {
            Vec3 a = pts.get(i), b = pts.get(i + 1);
            double seg = a.distanceTo(b);
            while (seg > 1e-6 && acc + seg >= want) {
                s.add(a.lerp(b, (want - acc) / seg));
                arc.add(want);
                want += STEP;
            }
            acc += seg;
        }
        if (acc - arc.get(arc.size() - 1) > 0.05) {
            s.add(pts.get(pts.size() - 1));
            arc.add(acc);
        }
        int n = s.size();
        if (n < 2) return;

        // a frame at each sample, carried along the body so it doesn't twist
        Vec3 aimFlat = dragon.dragonAim().subtract(head).multiply(1, 0, 1);
        Vec3 refUp = new Vec3(0, 1, 0);
        Vec3[] tan = new Vec3[n], nor = new Vec3[n], bin = new Vec3[n];
        for (int i = 0; i < n; i++) {
            Vec3 t = i == 0 ? s.get(0).subtract(s.get(1)) : i == n - 1 ? s.get(n - 2).subtract(s.get(n - 1)) : s.get(i - 1).subtract(s.get(i + 1));
            tan[i] = t.lengthSqr() > 1e-8 ? t.normalize() : (i > 0 ? tan[i - 1] : new Vec3(0, 1, 0));
            Vec3 up;
            if (i == 0) {
                up = refUp;
                if (Math.abs(tan[0].dot(up)) > 0.95) up = aimFlat.lengthSqr() > 1e-4 ? aimFlat.normalize().scale(-1) : new Vec3(1, 0, 0);
            } else {
                up = nor[i - 1];
            }
            Vec3 nn = up.subtract(tan[i].scale(up.dot(tan[i])));
            if (nn.lengthSqr() < 1e-8) nn = new Vec3(1, 0, 0).subtract(tan[i].scale(tan[i].x));
            nor[i] = nn.normalize();
            bin[i] = tan[i].cross(nor[i]).normalize();
        }
        // a gentle sideways ripple down the body
        Vec3[] c = new Vec3[n];
        for (int i = 0; i < n; i++) {
            double a = arc.get(i);
            double wig = Math.sin(a * 0.9 - time * 0.35) * 0.18 * scale * Math.min(1.0, a / 2.0);
            c[i] = s.get(i).add(bin[i].scale(wig)).subtract(head);
        }

        int light = Math.max(packedLight & 0xFFFF, 0x90) | (packedLight & 0xFFFF0000);
        ps.pushPose();
        Matrix4f pose = ps.last().pose();
        Matrix3f normal = ps.last().normal();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(TEXTURE));

        float r0 = 0.62f * scale;
        // body
        for (int i = 0; i + 1 < n; i++) {
            for (int k = 0; k < RING; k++) {
                float a0 = Mth.TWO_PI * k / RING, a1 = Mth.TWO_PI * (k + 1) / RING;
                ringVertex(vc, pose, normal, c[i], nor[i], bin[i], radius(arc.get(i), bodyLen, r0), a0, k / (float) RING * 2f,
                        (float) (arc.get(i) * 0.3 - time * 0.05), alpha(arc.get(i), bodyLen), light);
                ringVertex(vc, pose, normal, c[i + 1], nor[i + 1], bin[i + 1], radius(arc.get(i + 1), bodyLen, r0), a0, k / (float) RING * 2f,
                        (float) (arc.get(i + 1) * 0.3 - time * 0.05), alpha(arc.get(i + 1), bodyLen), light);
                ringVertex(vc, pose, normal, c[i + 1], nor[i + 1], bin[i + 1], radius(arc.get(i + 1), bodyLen, r0), a1, (k + 1) / (float) RING * 2f,
                        (float) (arc.get(i + 1) * 0.3 - time * 0.05), alpha(arc.get(i + 1), bodyLen), light);
                ringVertex(vc, pose, normal, c[i], nor[i], bin[i], radius(arc.get(i), bodyLen, r0), a1, (k + 1) / (float) RING * 2f,
                        (float) (arc.get(i) * 0.3 - time * 0.05), alpha(arc.get(i), bodyLen), light);
            }
        }
        // fins down the back, swept toward the tail
        for (int i = 1; i < n - 1; i++) {
            double a = arc.get(i);
            if (a < 1.4 * scale || a > bodyLen * 0.85 || (int) Math.round(a / STEP) % 3 != 0) continue;
            float f = (float) (a / bodyLen);
            float r = radius(a, bodyLen, r0);
            Vec3 base = c[i].add(nor[i].scale(r * 0.9));
            Vec3 front = base.add(tan[i].scale(0.32 * scale)), back = base.subtract(tan[i].scale(0.32 * scale));
            Vec3 tip = base.add(nor[i].scale(0.5 * scale * (1 - f))).subtract(tan[i].scale(0.45 * scale));
            int al = alpha(a, bodyLen);
            quad(vc, pose, normal, front, tip, tip, back, bin[i], 0.6f, 0.6f, light, al, 235, 250, 255);
        }

        // the head
        Head h = new Head(vc, pose, normal, c[0], bin[0].scale(-1), nor[0], tan[0], 0.8f * scale, light);
        float jaw = 0.32f + 0.1f * Mth.sin(time * 0.4f);
        h.box(0, 0.1f, 0, 0.5f, 0.4f, 0.55f, 0, 0, 0, 0, 0, 200, 230, 248, 255);              // skull
        h.box(0, 0.05f, 0.9f, 0.36f, 0.24f, 0.5f, 0, 0, 0, 0, 0, 205, 232, 248, 255);         // upper snout
        h.box(0, 0.22f, 1.25f, 0.2f, 0.1f, 0.14f, 0, 0, 0, 0, 0, 205, 232, 248, 255);         // nose
        h.box(0, -0.32f, 0.85f, 0.3f, 0.09f, 0.55f, 0, -0.2f, 0.35f, jaw, 0, 195, 228, 248, 255);  // lower jaw, open
        for (int t = 0; t < 4; t++) {                                                          // teeth
            float z = 0.6f + t * 0.2f;
            h.box(0.28f, -0.22f, z, 0.03f, 0.07f, 0.03f, 0, 0, 0, 0, 0, 240, 250, 255, 255);
            h.box(-0.28f, -0.22f, z, 0.03f, 0.07f, 0.03f, 0, 0, 0, 0, 0, 240, 250, 255, 255);
        }
        h.box(0.3f, 0.42f, 0.45f, 0.14f, 0.07f, 0.22f, 0, 0, 0, 0, 0, 215, 238, 250, 255);    // brows
        h.box(-0.3f, 0.42f, 0.45f, 0.14f, 0.07f, 0.22f, 0, 0, 0, 0, 0, 215, 238, 250, 255);
        h.box(0.32f, 0.55f, -0.75f, 0.06f, 0.06f, 0.5f, 0.3f, 0.4f, -0.2f, 0.35f, -0.2f, 225, 245, 255, 255);   // horns
        h.box(-0.32f, 0.55f, -0.75f, 0.06f, 0.06f, 0.5f, -0.3f, 0.4f, -0.2f, 0.35f, 0.2f, 225, 245, 255, 255);
        h.box(0, 0.5f, -0.4f, 0.05f, 0.18f, 0.25f, 0, 0, 0, 0, 0, 215, 240, 252, 255);         // mane
        h.box(0.25f, 0.35f, -0.6f, 0.05f, 0.15f, 0.22f, 0, 0, 0, 0, 0, 215, 240, 252, 255);
        h.box(-0.25f, 0.35f, -0.6f, 0.05f, 0.15f, 0.22f, 0, 0, 0, 0, 0, 215, 240, 252, 255);
        h.box(0.5f, -0.02f, 0.45f, 0.02f, 0.02f, 0.55f, 0.36f, 0, 0.9f, 0, -0.5f, 225, 245, 255, 230);   // whiskers
        h.box(-0.5f, -0.02f, 0.45f, 0.02f, 0.02f, 0.55f, -0.36f, 0, 0.9f, 0, 0.5f, 225, 245, 255, 230);
        h.light = LightTexture.FULL_BRIGHT;
        h.box(0.42f, 0.28f, 0.42f, 0.05f, 0.09f, 0.13f, 0, 0, 0, 0, 0, 255, 255, 255, 255);   // eyes
        h.box(-0.42f, 0.28f, 0.42f, 0.05f, 0.09f, 0.13f, 0, 0, 0, 0, 0, 255, 255, 255, 255);
        ps.popPose();
    }

    private static float radius(double a, double bodyLen, float r0) {
        float f = (float) Mth.clamp(a / bodyLen, 0, 1);
        float r = r0 * (1f - 0.78f * (float) Math.pow(f, 1.15));
        if (a < 0.6) r *= 0.82f;                       // the neck, just behind the head
        return r;
    }

    private static int alpha(double a, double bodyLen) {
        float f = (float) (a / bodyLen);
        return f < 0.85f ? 205 : Math.max(0, Math.round(205 * (1f - (f - 0.85f) / 0.15f)));
    }

    private static void ringVertex(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 c, Vec3 nor, Vec3 bin, float r, float ang,
                                   float u, float v, int alpha, int light) {
        Vec3 d = nor.scale(Mth.cos(ang)).add(bin.scale(Mth.sin(ang)));
        Vec3 p = c.add(d.scale(r));
        vc.vertex(pose, (float) p.x, (float) p.y, (float) p.z).color(205, 238, 252, alpha).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(normal, (float) d.x, (float) d.y, (float) d.z).endVertex();
    }

    private static void quad(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 a, Vec3 b, Vec3 cc, Vec3 d, Vec3 n, float u, float v,
                             int light, int alpha, int r, int g, int bl) {
        for (Vec3 p : new Vec3[]{a, b, cc, d}) {
            vc.vertex(pose, (float) p.x, (float) p.y, (float) p.z).color(r, g, bl, alpha).uv(u, v)
                    .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(normal, (float) n.x, (float) n.y, (float) n.z).endVertex();
        }
    }

    /** Boxes in the head's own frame (x to its left, y up, z forward), in units of {@code k} blocks. */
    static final class Head {
        final VertexConsumer vc;
        final Matrix4f pose;
        final Matrix3f normal;
        final Vec3 o, x, y, z;
        final float k;
        int light;

        Head(VertexConsumer vc, Matrix4f pose, Matrix3f normal, Vec3 o, Vec3 x, Vec3 y, Vec3 z, float k, int light) {
            this.vc = vc;
            this.pose = pose;
            this.normal = normal;
            this.o = o;
            this.x = x;
            this.y = y;
            this.z = z;
            this.k = k;
            this.light = light;
        }

        /**
         * A box centred on (cx, cy, cz) with half sizes (hx, hy, hz), tipped by {@code pitch} (front end down) and
         * turned by {@code yaw} (front end outward) about the pivot (px, py, pz).
         */
        void box(float cx, float cy, float cz, float hx, float hy, float hz, float px, float py, float pz, float pitch, float yaw,
                 int r, int g, int b, int alpha) {
            Vec3[] q = new Vec3[8];
            int i = 0;
            for (int sx = -1; sx <= 1; sx += 2) {
                for (int sy = -1; sy <= 1; sy += 2) {
                    for (int sz = -1; sz <= 1; sz += 2) {
                        float lx = cx + sx * hx, ly = cy + sy * hy, lz = cz + sz * hz;
                        float dy = ly - py, dz = lz - pz;
                        float ry = py + dy * Mth.cos(pitch) - dz * Mth.sin(pitch);
                        float rz = pz + dy * Mth.sin(pitch) + dz * Mth.cos(pitch);
                        float dx = lx - px;
                        dz = rz - pz;
                        float rx = px + dx * Mth.cos(yaw) + dz * Mth.sin(yaw);
                        rz = pz - dx * Mth.sin(yaw) + dz * Mth.cos(yaw);
                        q[i++] = o.add(x.scale(rx * k)).add(y.scale(ry * k)).add(z.scale(rz * k));
                    }
                }
            }
            // corners: index = (sx>0)*4 + (sy>0)*2 + (sz>0)
            face(q[0], q[1], q[3], q[2], r, g, b, alpha);   // -x
            face(q[4], q[6], q[7], q[5], r, g, b, alpha);   // +x
            face(q[0], q[4], q[5], q[1], r, g, b, alpha);   // -y
            face(q[2], q[3], q[7], q[6], r, g, b, alpha);   // +y
            face(q[0], q[2], q[6], q[4], r, g, b, alpha);   // -z
            face(q[1], q[5], q[7], q[3], r, g, b, alpha);   // +z
        }

        private void face(Vec3 a, Vec3 b, Vec3 c, Vec3 d, int r, int g, int bl, int alpha) {
            Vec3 n = b.subtract(a).cross(d.subtract(a));
            n = n.lengthSqr() > 1e-10 ? n.normalize() : y;
            vertex(a, 0, 0, n, r, g, bl, alpha);
            vertex(b, 0, 1, n, r, g, bl, alpha);
            vertex(c, 1, 1, n, r, g, bl, alpha);
            vertex(d, 1, 0, n, r, g, bl, alpha);
        }

        private void vertex(Vec3 p, float u, float v, Vec3 n, int r, int g, int b, int alpha) {
            vc.vertex(pose, (float) p.x, (float) p.y, (float) p.z).color(r, g, b, alpha).uv(u * 0.5f, v * 0.5f)
                    .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(normal, (float) n.x, (float) n.y, (float) n.z).endVertex();
        }
    }
}
