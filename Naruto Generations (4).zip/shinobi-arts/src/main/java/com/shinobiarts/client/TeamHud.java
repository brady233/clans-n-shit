package com.shinobiarts.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * Your team on screen (top left): the team's name, then each teammate who's online with their level and a health bar
 * that turns from green to red as they get hurt. Offline teammates are listed greyed out. Updated every second.
 */
public final class TeamHud {
    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g);
    private static final int X = 4, Y = 4, W = 104;

    private TeamHud() {}

    private static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.options.renderDebug) return;
        CompoundTag team = ClientNinjaData.team();
        if (!team.contains("Name")) return;
        ListTag members = team.getList("Members", Tag.TAG_COMPOUND);
        String me = mc.player.getGameProfile().getName();
        int shown = 0;
        for (int i = 0; i < members.size(); i++) if (!members.getCompound(i).getString("Name").equals(me)) shown++;
        if (shown == 0) return;
        Font font = mc.font;
        int h = 12 + shown * 18;
        g.fill(X - 2, Y - 2, X + W + 2, Y + h, 0x80000000);
        g.drawString(font, font.plainSubstrByWidth(team.getString("Name"), W), X, Y, 0xFF8FC7FF, true);
        int y = Y + 12;
        for (int i = 0; i < members.size(); i++) {
            CompoundTag m = members.getCompound(i);
            String name = m.getString("Name");
            if (name.equals(me)) continue;
            boolean online = m.getBoolean("Online");
            String lv = online && m.contains("Level") ? "Lv " + m.getInt("Level") : "";
            int lvW = font.width(lv);
            g.drawString(font, font.plainSubstrByWidth(name, W - lvW - 4), X, y, online ? 0xFFFFFFFF : 0xFF888888, true);
            if (!lv.isEmpty()) g.drawString(font, lv, X + W - lvW, y, 0xFFE8D27A, true);
            if (online && m.contains("MaxHealth")) healthBar(g, font, X, y + 10, W, m.getFloat("Health"), m.getFloat("MaxHealth"), true);
            y += 18;
        }
    }

    /** A thin health bar, green when full, red when low, with the numbers on it if {@code numbers}. */
    static void healthBar(GuiGraphics g, Font font, int x, int y, int w, float health, float max, boolean numbers) {
        float frac = max <= 0 ? 0f : Mth.clamp(health / max, 0f, 1f);
        int r = (int) (230 * (1 - frac) + 60 * frac), gr = (int) (60 * (1 - frac) + 200 * frac);
        g.fill(x, y, x + w, y + 5, 0xFF1A1A1A);
        g.fill(x + 1, y + 1, x + 1 + Math.round((w - 2) * frac), y + 4, 0xFF000000 | (r << 16) | (gr << 8) | 50);
    }
}
