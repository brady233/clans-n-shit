package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Shakes the camera, e.g. when Chibaku Tensei blows apart or a Tengai Shinsei meteor lands: stronger the closer you
 * are, dying away over its time. Started from the effects themselves, so every player near enough feels it.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, value = Dist.CLIENT)
public final class CameraShake {
    private CameraShake() {}

    private static float strength;
    private static int ticks, total;

    /** Starts (or strengthens) a shake from something at {@code at}: {@code power} degrees right next to it, felt out to {@code range}. */
    public static void from(Vec3 at, float power, double range, int duration) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        double d = mc.player.position().distanceTo(at);
        if (d > range) return;
        float s = power * (float) (1 - d / range);
        if (s * Math.max(1, ticks) >= strength * Math.max(1, ticks) || ticks <= 0) {
            strength = Math.max(strength * (ticks > 0 ? 1 : 0), s);
            ticks = total = duration;
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END && ticks > 0 && --ticks == 0) strength = 0;
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (ticks <= 0 || strength <= 0) return;
        float left = (ticks - (float) event.getPartialTick()) / Math.max(1, total);
        float s = strength * Math.max(0, left);
        double t = (Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime()) + event.getPartialTick();
        event.setYaw(event.getYaw() + (float) (Math.sin(t * 2.9) + Math.sin(t * 7.3) * 0.5) * s * 0.6f);
        event.setPitch(event.getPitch() + (float) (Math.cos(t * 3.7) + Math.sin(t * 9.1) * 0.5) * s * 0.6f);
        event.setRoll(event.getRoll() + (float) Math.sin(t * 5.3) * s * 0.4f);
    }
}
