package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.ForeheadProtectorItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

/**
 * Draws a worn forehead protector: a dyed cloth band round the head just above the brows, a knot with two tails at the
 * back, and the metal plate lying flat on the front of the band, inside its top and bottom edges. The plates come from
 * Calfan's "Naruto Headbands" model (see tools/make_headbands.py). Positions are in the head's model pixels (the head
 * runs from y -8 at the top to 0, and faces -Z).
 */
public class HeadbandLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation BAND = new ResourceLocation(ShinobiArts.MODID, "textures/entity/headband/band.png");
    private static final String[] DEFAULT_VILLAGES = {"leaf", "sand", "mist", "cloud", "stone"};
    private static final Map<String, ResourceLocation> PLATES = new HashMap<>();

    /** The band's top and bottom (head pixels); the plate sits inside them, PLATE_MARGIN from each edge. */
    private static final float BAND_TOP = -7.55f, BAND_BOTTOM = -5.35f;
    private static final float PLATE_MARGIN = 0.1f, PLATE_THICKNESS = 0.3f, PLATE_ASPECT = 512f / 173f;

    public HeadbandLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    /** Item model override value: 0 never worn, 0.1 no village, 0.2-0.6 the five villages, 0.7 any other village. */
    public static float iconValue(@Nullable String village) {
        if (village == null) return 0f;
        if (village.isEmpty()) return 0.15f;                     // halfway between steps, so float rounding can't tip it
        for (int i = 0; i < DEFAULT_VILLAGES.length; i++) {
            if (DEFAULT_VILLAGES[i].equals(village)) return 0.25f + i * 0.1f;
        }
        return 0.75f;
    }

    /**
     * The plate texture for a village: plate_<id>.png if it exists (leaf, sand, mist, cloud, rain and sound are built
     * in, and a resource pack can add more), else the 忍 plate. No village: the scratched plate. Never worn: 忍.
     */
    private static ResourceLocation plate(@Nullable String village) {
        String key = village == null ? "<none>" : village;
        return PLATES.computeIfAbsent(key, k -> {
            if (village == null) return tex("plate_shinobi");
            if (village.isEmpty()) return tex("plate_rogue");
            ResourceLocation own = tex("plate_" + village);
            if (Minecraft.getInstance().getResourceManager().getResource(own).isPresent()) return own;
            return tex("plate_shinobi");
        });
    }

    /** Forget cached plates (the village list may have changed, e.g. on joining another server). */
    public static void clearCache() {
        PLATES.clear();
    }

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(ShinobiArts.MODID, "textures/entity/headband/" + name + ".png");
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int light, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        ItemStack head = entity.getItemBySlot(EquipmentSlot.HEAD);
        if (!(head.getItem() instanceof ForeheadProtectorItem item) || entity.isInvisible()) return;
        int color = item.getColor(head);
        float r = ((color >> 16) & 255) / 255f, g = ((color >> 8) & 255) / 255f, b = (color & 255) / 255f;

        poseStack.pushPose();
        getParentModel().head.translateAndRotate(poseStack);
        PoseStack.Pose pose = poseStack.last();

        VertexConsumer band = buffer.getBuffer(RenderType.entityCutoutNoCull(BAND));
        float[] all = {0, 0, 1, 1};
        box(pose, band, -4.75f, BAND_TOP, -4.75f, 4.75f, BAND_BOTTOM, 4.75f, all, all, r, g, b, light); // the band
        box(pose, band, -0.9f, -7.2f, 4.75f, 0.9f, -5.7f, 5.45f, all, all, r * 0.85f, g * 0.85f, b * 0.85f, light); // knot
        box(pose, band, -1.0f, -5.9f, 5.05f, -0.2f, -2.2f, 5.3f, all, all, r, g, b, light);         // the two tails
        box(pose, band, 0.2f, -5.9f, 5.15f, 1.0f, -2.9f, 5.4f, all, all, r * 0.9f, g * 0.9f, b * 0.9f, light);

        // the plate: flat on the front of the band, inside its top and bottom edges (the model's plates are 89 x 30)
        VertexConsumer plate = buffer.getBuffer(RenderType.entityCutoutNoCull(plate(ForeheadProtectorItem.village(head))));
        float h = (BAND_BOTTOM - BAND_TOP) - 2 * PLATE_MARGIN, w = h * PLATE_ASPECT;
        float x0 = -w / 2, x1 = w / 2, y0 = BAND_TOP + PLATE_MARGIN, y1 = BAND_BOTTOM - PLATE_MARGIN;
        float z1 = -4.75f, z0 = z1 - PLATE_THICKNESS, s = 1f / 16f;
        float[] metal = {0.18f, 0.08f, 0.22f, 0.14f};                                               // plain metal on the plate
        quad(pose, plate, x0 * s, y0 * s, z0 * s, x1 * s, y0 * s, z0 * s, x1 * s, y1 * s, z0 * s, x0 * s, y1 * s, z0 * s, all, 0, 0, -1, 1f, 1f, 1f, light);
        float inset = w * 0.06f;                                    // the ends are rounded: the top and bottom edges stop short
        quad(pose, plate, (x0 + inset) * s, y0 * s, z1 * s, (x1 - inset) * s, y0 * s, z1 * s, (x1 - inset) * s, y0 * s, z0 * s, (x0 + inset) * s, y0 * s, z0 * s, metal, 0, -1, 0, 1f, 1f, 1f, light);
        quad(pose, plate, (x0 + inset) * s, y1 * s, z0 * s, (x1 - inset) * s, y1 * s, z0 * s, (x1 - inset) * s, y1 * s, z1 * s, (x0 + inset) * s, y1 * s, z1 * s, metal, 0, 1, 0, 1f, 1f, 1f, light);
        poseStack.popPose();
    }

    /**
     * A box from (x0,y0,z0) to (x1,y1,z1) in model pixels. {@code front} is the UV rectangle (u0, v0, u1, v1) of the
     * -Z face (the side facing forward), {@code other} the one used on every other face.
     */
    private static void box(PoseStack.Pose pose, VertexConsumer vc, float x0, float y0, float z0, float x1, float y1, float z1,
                            float[] front, float[] other, float r, float g, float b, int light) {
        float s = 1f / 16f;
        x0 *= s; y0 *= s; z0 *= s; x1 *= s; y1 *= s; z1 *= s;
        // front (-Z): the texture's left edge on the wearer's right, as on a skin's face
        quad(pose, vc, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, front, 0, 0, -1, r, g, b, light);
        quad(pose, vc, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, other, 0, 0, 1, r, g, b, light);   // back
        quad(pose, vc, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, other, -1, 0, 0, r, g, b, light);  // -X side
        quad(pose, vc, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, other, 1, 0, 0, r, g, b, light);   // +X side
        quad(pose, vc, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, other, 0, -1, 0, r, g, b, light);  // top (-Y)
        quad(pose, vc, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, other, 0, 1, 0, r, g, b, light);   // bottom
    }

    private static void quad(PoseStack.Pose pose, VertexConsumer vc, float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz, float[] uv, float nx, float ny, float nz,
                             float r, float g, float b, int light) {
        Matrix4f m = pose.pose();
        Matrix3f n = pose.normal();
        vc.vertex(m, ax, ay, az).color(r, g, b, 1f).uv(uv[0], uv[1]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
        vc.vertex(m, bx, by, bz).color(r, g, b, 1f).uv(uv[2], uv[1]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
        vc.vertex(m, cx, cy, cz).color(r, g, b, 1f).uv(uv[2], uv[3]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
        vc.vertex(m, dx, dy, dz).color(r, g, b, 1f).uv(uv[0], uv[3]).overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(n, nx, ny, nz).endVertex();
    }
}
