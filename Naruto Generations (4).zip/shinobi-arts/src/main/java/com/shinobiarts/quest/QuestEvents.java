package com.shinobiarts.quest;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.NinjaBandit;
import com.shinobiarts.entity.ShadowClone;
import com.shinobiarts.pvp.PvpRewards;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.ItemFishedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/**
 * Quest progress: bandit and mob kills (your clones' and jutsu kills count), fish caught, and PvP kills
 * (only kills that give PvP rewards, so friends can't farm each other; counted from PvpRewards). Gather quests
 * are checked every two seconds.
 */
@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class QuestEvents {
    private QuestEvents() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (event.isCanceled() || victim.level().isClientSide || victim instanceof Player || victim instanceof ShadowClone) return;
        ServerPlayer killer = PvpRewards.responsiblePlayer(event.getSource());
        if (killer == null) return;
        PlayerQuests quests = PlayerQuests.of(killer);
        if (victim instanceof NinjaBandit) quests.addProgress(QuestType.KILL_BANDITS, 1);
        if (victim instanceof Enemy) quests.addProgress(QuestType.KILL_MOBS, 1);
    }

    @SubscribeEvent
    public static void onFished(ItemFishedEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        for (ItemStack drop : event.getDrops()) {
            if (drop.is(ItemTags.FISHES)) {
                PlayerQuests.of(player).addProgress(QuestType.FISH, 1);
                return;
            }
        }
    }

    /** Called by PvpRewards for a rewarded player kill. */
    public static void onPlayerKill(ServerPlayer killer) {
        PlayerQuests.of(killer).addProgress(QuestType.KILL_PLAYERS, 1);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.side == LogicalSide.SERVER && event.player instanceof ServerPlayer player
                && player.tickCount % 40 == 13) {
            PlayerQuests.of(player).checkGather();
        }
    }
}
