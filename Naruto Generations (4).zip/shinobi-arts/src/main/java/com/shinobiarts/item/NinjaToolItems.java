package com.shinobiarts.item;

import com.shinobiarts.entity.ExplosiveKunaiEntity;
import com.shinobiarts.entity.SmokeBombEntity;
import com.shinobiarts.entity.WireTrapEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

/** The ninja tools: smoke bombs, wire traps and explosive-tag kunai. */
public final class NinjaToolItems {
    private NinjaToolItems() {}

    /** Right-click to throw: it bursts into a cloud of blinding smoke where it lands. */
    public static class SmokeBomb extends Item {
        public SmokeBomb(Properties properties) {
            super(properties);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.6f, 0.5f);
            if (!level.isClientSide) {
                SmokeBombEntity bomb = new SmokeBombEntity(level, player);
                ItemStack one = stack.copy();
                one.setCount(1);
                bomb.setItem(one);
                bomb.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 1.3f, 0.6f);
                level.addFreshEntity(bomb);
            }
            player.getCooldowns().addCooldown(this, 20);
            player.awardStat(Stats.ITEM_USED.get(this));
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.smoke_bomb").withStyle(ChatFormatting.GRAY));
        }
    }

    /** Right-click a block, then a second one (up to 12 blocks away): a wire is strung between them. */
    public static class WireTrap extends Item {
        public static final double MAX_SPAN = 12;

        public WireTrap(Properties properties) {
            super(properties);
        }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Player player = ctx.getPlayer();
            Level level = ctx.getLevel();
            if (player == null) return InteractionResult.PASS;
            ItemStack stack = ctx.getItemInHand();
            Vec3 point = anchor(ctx.getClickedPos(), ctx.getClickedFace());
            if (level.isClientSide) return InteractionResult.SUCCESS;
            CompoundTag tag = stack.getTag();
            if (tag == null || !tag.contains("WireFrom")) {                // the first end
                CompoundTag t = stack.getOrCreateTag();
                t.putDouble("WireFromX", point.x);
                t.putDouble("WireFromY", point.y);
                t.putDouble("WireFromZ", point.z);
                t.putString("WireFrom", level.dimension().location().toString());
                player.displayClientMessage(Component.translatable("message.shinobiarts.wire_first"), true);
                level.playSound(null, point.x, point.y, point.z, SoundEvents.TRIPWIRE_ATTACH, SoundSource.PLAYERS, 0.8f, 1.2f);
                return InteractionResult.CONSUME;
            }
            Vec3 from = new Vec3(tag.getDouble("WireFromX"), tag.getDouble("WireFromY"), tag.getDouble("WireFromZ"));
            boolean sameLevel = tag.getString("WireFrom").equals(level.dimension().location().toString());
            clear(stack);
            double span = from.distanceTo(point);
            if (!sameLevel || span > MAX_SPAN || span < 1.5) {
                player.displayClientMessage(Component.translatable("message.shinobiarts.wire_too_far", (int) MAX_SPAN).withStyle(ChatFormatting.RED), true);
                return InteractionResult.CONSUME;
            }
            level.addFreshEntity(WireTrapEntity.create(level, from, point, player));
            level.playSound(null, point.x, point.y, point.z, SoundEvents.TRIPWIRE_ATTACH, SoundSource.PLAYERS, 0.8f, 0.9f);
            player.displayClientMessage(Component.translatable("message.shinobiarts.wire_set").withStyle(ChatFormatting.GRAY), true);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResult.CONSUME;
        }

        /** Sneak + right-click the air: forget the first end. */
        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player.isShiftKeyDown() && stack.hasTag() && stack.getTag().contains("WireFrom")) {
                if (!level.isClientSide) {
                    clear(stack);
                    player.displayClientMessage(Component.translatable("message.shinobiarts.wire_cancel"), true);
                }
                return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
            }
            return InteractionResultHolder.pass(stack);
        }

        private static void clear(ItemStack stack) {
            CompoundTag t = stack.getTag();
            if (t == null) return;
            for (String k : new String[]{"WireFrom", "WireFromX", "WireFromY", "WireFromZ"}) t.remove(k);
            if (t.isEmpty()) stack.setTag(null);
        }

        /** A point just off the clicked face, a little above the block's middle (shin height on the ground). */
        private static Vec3 anchor(BlockPos pos, Direction face) {
            Vec3 c = Vec3.atCenterOf(pos).add(face.getStepX() * 0.52, face.getStepY() * 0.52, face.getStepZ() * 0.52);
            return face == Direction.UP ? c.add(0, 0.4, 0) : c;
        }

        @Override
        public boolean isFoil(ItemStack stack) {
            return stack.hasTag() && stack.getTag().contains("WireFrom");
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.wire_trap").withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("tooltip.shinobiarts.wire_trap_2").withStyle(ChatFormatting.GRAY));
        }
    }

    /** A kunai with an explosive tag: right-click to throw, it sticks and blows a moment later. */
    public static class ExplosiveKunai extends ThrownToolItem {
        public ExplosiveKunai(Properties properties) {
            super(properties, 2.0f, 16, 4.0, -2.0);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 0.5f, 1.4f);
            if (!level.isClientSide) {
                ExplosiveKunaiEntity kunai = new ExplosiveKunaiEntity(level, player);
                kunai.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, 2.2f, 0.6f);
                level.addFreshEntity(kunai);
            }
            player.getCooldowns().addCooldown(this, 16);
            player.awardStat(Stats.ITEM_USED.get(this));
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.explosive_kunai").withStyle(ChatFormatting.GRAY));
        }
    }
}
