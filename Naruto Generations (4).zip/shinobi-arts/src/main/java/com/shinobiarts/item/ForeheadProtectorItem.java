package com.shinobiarts.item;

import com.shinobiarts.village.Villages;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.DyeableLeatherItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * A forehead protector, worn in the helmet slot. Its metal plate shows the village of whoever wears it (engraved
 * kanji); someone with no village wears it scratched through, like a rogue ninja. The cloth band can be dyed like
 * leather armor (navy blue by default). The wearer's village is stored on the item ("Village") by the server, so every
 * client draws the right plate. It's drawn by HeadbandLayer; the vanilla armor texture is left empty.
 */
public class ForeheadProtectorItem extends ArmorItem implements DyeableLeatherItem {
    public static final int DEFAULT_COLOR = 0x23366E;
    private static final String VILLAGE = "Village";

    public static final ArmorMaterial MATERIAL = new ArmorMaterial() {
        @Override
        public int getDurabilityForType(Type type) {
            return 165;
        }

        @Override
        public int getDefenseForType(Type type) {
            return 1;
        }

        @Override
        public int getEnchantmentValue() {
            return 12;
        }

        @Override
        public SoundEvent getEquipSound() {
            return SoundEvents.ARMOR_EQUIP_IRON;
        }

        @Override
        public Ingredient getRepairIngredient() {
            return Ingredient.of(Items.IRON_INGOT);
        }

        @Override
        public String getName() {
            return "shinobiarts:forehead_protector";
        }

        @Override
        public float getToughness() {
            return 0f;
        }

        @Override
        public float getKnockbackResistance() {
            return 0f;
        }
    };

    public ForeheadProtectorItem(Properties properties) {
        super(MATERIAL, Type.HELMET, properties);
    }

    @Override
    public int getColor(ItemStack stack) {
        CompoundTag display = stack.getTagElement("display");
        return display != null && display.contains("color", 99) ? display.getInt("color") : DEFAULT_COLOR;
    }

    /** The village shown on the plate: an id, "" for none (scratched through), or null if nobody has worn it yet. */
    @Nullable
    public static String village(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(VILLAGE) ? tag.getString(VILLAGE) : null;
    }

    public static void setVillage(ItemStack stack, String village) {
        stack.getOrCreateTag().putString(VILLAGE, village == null ? "" : village);
    }

    /** The vanilla armor layer draws nothing; HeadbandLayer draws the band and plate. */
    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return "shinobiarts:textures/models/armor/empty.png";
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        String village = village(stack);
        if (village == null) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.headband_unworn").withStyle(ChatFormatting.GRAY));
        } else if (village.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.headband_rogue").withStyle(ChatFormatting.DARK_GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.shinobiarts.headband_village", Villages.name(village)).withStyle(ChatFormatting.AQUA));
        }
        tooltip.add(Component.translatable("tooltip.shinobiarts.headband_dye").withStyle(ChatFormatting.DARK_GRAY));
    }
}
