package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * A chakra projectile (fireball, water bullet, water dragon...). The Great Fireball and the Water Bullet are drawn
 * as glowing sprites (client/JutsuProjectileRenderer); everything leaves a particle trail. The Great Fireball's
 * size (and blast radius) follows how long it was charged: {@link #getScale}.
 */
public class JutsuProjectile extends ThrowableProjectile {
    public enum Kind { FIRE_BALL, FIRE_SMALL, WATER_BULLET, WATER_DRAGON, RASENGAN, RASENSHURIKEN, ICE_NEEDLE, BONE_BULLET, MAGATAMA, WATER_SHARK, KAMUI_SHURIKEN, SUSANOO_ARROW }

    private static final EntityDataAccessor<Byte> KIND = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Float> SCALE = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.FLOAT);
    /** Chakra colour of a Susanoo's magatama (its owner's chosen colour). */
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.INT);
    /** Water Dragon: the point it flies to after rising out of the ground (both sides steer the same way). */
    private static final EntityDataAccessor<Vector3f> AIM = SynchedEntityData.defineId(JutsuProjectile.class, EntityDataSerializers.VECTOR3);
    /** Water Dragon: ticks spent rising straight up out of the ground before it turns toward its aim. */
    public static final int DRAGON_RISE = 7;
    public static final float DRAGON_SPEED = 1.15f;
    private static final DustParticleOptions WATER_DUST = new DustParticleOptions(new Vector3f(0.2f, 0.5f, 1.0f), 1.4f);
    private static final DustParticleOptions WATER_DUST_BIG = new DustParticleOptions(new Vector3f(0.15f, 0.4f, 0.95f), 2.4f);
    private static final DustParticleOptions CHAKRA_DUST = new DustParticleOptions(new Vector3f(0.45f, 0.8f, 1.0f), 1.3f);
    private static final DustParticleOptions WIND_DUST = new DustParticleOptions(new Vector3f(0.85f, 0.95f, 1.0f), 1.6f);
    private static final DustParticleOptions ICE_DUST = new DustParticleOptions(new Vector3f(0.75f, 0.92f, 1.0f), 0.7f);
    private static final DustParticleOptions BONE_DUST = new DustParticleOptions(new Vector3f(0.95f, 0.92f, 0.82f), 0.8f);
    private static final int MAX_LIFE = 80;

    private float damage = 5f;
    private int homingTarget = -1; // magatama: the creature it curves toward
    private int reflectedBy = -1;  // a Gunbai sent it back: it doesn't hit the guard again on its way out

    public JutsuProjectile(EntityType<? extends JutsuProjectile> type, Level level) {
        super(type, level);
    }

    public static JutsuProjectile shoot(ServerPlayer owner, Kind kind, float speed, float yawOffset, float damage) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        Vec3 eye = owner.getEyePosition();
        p.setPos(eye.x, eye.y - 0.3, eye.z);
        p.setKind(kind);
        p.damage = damage;
        p.shootFromRotation(owner, owner.getXRot(), owner.getYRot() + yawOffset, 0.0f, speed, 0.5f);
        p.sizeFromCast();
        owner.level().addFreshEntity(p);
        return p;
    }

    /**
     * Fired by any creature (e.g. a shadow clone) at a target; the damage is credited to {@code owner}
     * (the clone's player), so it counts as theirs and never hits them or their own clones.
     */
    public static JutsuProjectile shootAt(LivingEntity shooter, @javax.annotation.Nullable Entity owner, Kind kind, float speed,
                                          float damage, LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), shooter.level());
        p.setOwner(owner != null ? owner : shooter);
        Vec3 eye = shooter.getEyePosition();
        p.setPos(eye.x, eye.y - 0.3, eye.z);
        p.setKind(kind);
        p.damage = damage;
        Vec3 aim = target.getBoundingBox().getCenter().subtract(p.position());
        p.shoot(aim.x, aim.y, aim.z, speed, 0.5f);
        p.sizeFromCast();
        shooter.level().addFreshEntity(p);
        return p;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(KIND, (byte) 0);
        this.entityData.define(SCALE, 1.0f);
        this.entityData.define(COLOR, 0x8A55FF);
        this.entityData.define(AIM, new Vector3f());
    }

    /**
     * The Water Dragon: rises out of the ground at {@code from} (in front of the caster), then curves over to
     * {@code aim} and flies on through it until it hits something.
     */
    public static JutsuProjectile waterDragon(ServerPlayer owner, Vec3 from, Vec3 aim, float damage, float scale) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        p.setPos(from.x, from.y, from.z);
        p.setKind(Kind.WATER_DRAGON);
        p.damage = damage;
        p.sizeFromCast();
        p.setScale(scale);
        p.entityData.set(AIM, new Vector3f((float) aim.x, (float) aim.y, (float) aim.z));
        p.setDeltaMovement(0, 0.6, 0);
        owner.level().addFreshEntity(p);
        return p;
    }

    private boolean dragonPastAim;

    /** The jutsu that fired this (for death messages), fixed when it's thrown so a later cast doesn't rename it. */
    @javax.annotation.Nullable
    private String jutsuId;

    @javax.annotation.Nullable
    public String jutsuId() {
        return jutsuId;
    }

    @Override
    public void setOwner(@javax.annotation.Nullable Entity owner) {
        super.setOwner(owner);
        if (jutsuId == null && owner != null && !owner.level().isClientSide) jutsuId = JutsuUtil.lastJutsu(owner);
    }

    /** Water Dragon: where it's flying to (for the renderer). */
    public Vec3 dragonAim() {
        Vector3f a = this.entityData.get(AIM);
        return new Vec3(a.x(), a.y(), a.z());
    }

    /** Water Dragon steering, run the same on both sides so the curve looks smooth everywhere. */
    private void steerDragon() {
        Vector3f a = this.entityData.get(AIM);
        Vec3 aim = new Vec3(a.x(), a.y(), a.z());
        Vec3 to = aim.subtract(position());
        if (tickCount < DRAGON_RISE) {
            Vec3 flat = new Vec3(to.x, 0, to.z);
            Vec3 side = flat.lengthSqr() > 1e-4 ? flat.normalize().scale(0.12) : Vec3.ZERO;
            setDeltaMovement(new Vec3(side.x, 0.62 - tickCount * 0.03, side.z));
            return;
        }
        if (to.lengthSqr() < 2.5 * 2.5) dragonPastAim = true;
        Vec3 v = getDeltaMovement();
        if (v.lengthSqr() < 1e-6) v = to;
        Vec3 dir = v.normalize();
        if (!dragonPastAim && to.lengthSqr() > 1e-4) dir = dir.lerp(to.normalize(), 0.3).normalize();
        setDeltaMovement(dir.scale(DRAGON_SPEED));
    }

    /** The Water Dragon's body trails far behind its head: drawn whenever any of it could be on screen. */
    @Override
    public net.minecraft.world.phys.AABB getBoundingBoxForCulling() {
        if (getKind() == Kind.WATER_DRAGON) return getBoundingBox().inflate(17.0 * getScale());
        return super.getBoundingBoxForCulling();
    }

    /**
     * A Susanoo's magatama (Humanoid stage): flies from {@code from} along {@code dir} and curves toward
     * {@code target} (or the nearest creature ahead), in the owner's chakra colour.
     */
    public static JutsuProjectile magatama(ServerPlayer owner, Vec3 from, Vec3 dir, float damage, int color,
                                           @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        p.setPos(from.x, from.y, from.z);
        p.setKind(Kind.MAGATAMA);
        p.damage = damage;
        p.entityData.set(COLOR, color & 0xFFFFFF);
        p.homingTarget = target == null ? -1 : target.getId();
        p.shoot(dir.x, dir.y, dir.z, 1.6f, 0.0f);
        owner.level().addFreshEntity(p);
        return p;
    }

    /** Sasuke's Susanoo: a great arrow of chakra loosed from its bow, curving onto {@code target}, bursting on impact. */
    public static JutsuProjectile susanooArrow(ServerPlayer owner, Vec3 from, Vec3 dir, float damage, int color, float scale,
                                               @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        p.setPos(from.x, from.y, from.z);
        p.setKind(Kind.SUSANOO_ARROW);
        p.damage = damage;
        p.entityData.set(COLOR, color & 0xFFFFFF);
        p.setScale(scale);
        p.homingTarget = target == null ? -1 : target.getId();
        p.shoot(dir.x, dir.y, dir.z, 3.0f, 0.0f);
        owner.level().addFreshEntity(p);
        return p;
    }

    /** Its chakra colour (magatama, Susanoo arrows). */
    public int getColor() {
        return entityData.get(COLOR);
    }

    /**
     * Obito's Perfect Susanoo: a huge black shuriken from its hand that spins in, curving toward {@code target}, and
     * warps away whatever it hits (see onHitEntity).
     */
    public static JutsuProjectile kamuiShuriken(ServerPlayer owner, Vec3 from, Vec3 dir,
                                                @javax.annotation.Nullable net.minecraft.world.entity.LivingEntity target) {
        JutsuProjectile p = new JutsuProjectile(ModEntities.JUTSU_PROJECTILE.get(), owner.level());
        p.setOwner(owner);
        p.setPos(from.x, from.y, from.z);
        p.setKind(Kind.KAMUI_SHURIKEN);
        p.damage = 0f;
        p.setScale(2.8f);
        p.homingTarget = target == null ? -1 : target.getId();
        p.shoot(dir.x, dir.y, dir.z, 1.5f, 0.0f);
        owner.level().addFreshEntity(p);
        return p;
    }

    /** Share of max health a Kamui shuriken takes: a player's head 110%, a player's body 15%, anything else 10%. */
    public static float kamuiShare(Entity target, boolean head) {
        if (target instanceof Player) return head ? com.shinobiarts.Config.f(com.shinobiarts.Config.KAMUI_SHURIKEN_HEAD)
                : com.shinobiarts.Config.f(com.shinobiarts.Config.KAMUI_SHURIKEN_BODY);
        return com.shinobiarts.Config.f(com.shinobiarts.Config.KAMUI_SHURIKEN_MOB);
    }

    /**
     * Sent back by a guarding Gunbai: it now belongs to the guard, flies along {@code velocity} for a full lifetime,
     * and a magatama curves toward whoever threw it.
     */
    public void reflect(Entity guard, Vec3 velocity) {
        Entity thrower = getOwner();
        setOwner(guard);
        reflectedBy = guard.getId();
        homingTarget = thrower != null && thrower != guard ? thrower.getId() : -1;
        tickCount = 0;
        setDeltaMovement(velocity);
        hasImpulse = true;
    }

    /** Magatama: turn toward the target (or the nearest creature ahead within 32 blocks). */
    private void home() {
        Entity t = homingTarget >= 0 ? level().getEntity(homingTarget) : null;
        if (!(t instanceof net.minecraft.world.entity.LivingEntity lt) || !lt.isAlive()) {
            t = null;
            Vec3 ahead = getDeltaMovement().normalize();
            double best = 32 * 32;
            for (net.minecraft.world.entity.LivingEntity c : level().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,
                    getBoundingBox().inflate(32), c -> JutsuUtil.isValidTarget(getOwner(), c))) {
                Vec3 to = c.getBoundingBox().getCenter().subtract(position());
                double d2 = to.lengthSqr();
                if (d2 < best && to.normalize().dot(ahead) > 0.3) {
                    best = d2;
                    t = c;
                }
            }
            homingTarget = t == null ? -1 : t.getId();
        }
        if (t == null) return;
        Vec3 want = t.getBoundingBox().getCenter().subtract(position()).normalize().scale(1.6);
        Vec3 v = getDeltaMovement().lerp(want, 0.25);
        setDeltaMovement(v.normalize().scale(1.6));
    }

    /** Size multiplier (1 = normal). The Great Fireball's is about 0.45 for a tap and 2.6 at full charge. */
    public float getScale() {
        return this.entityData.get(SCALE);
    }

    /**
     * A Kamui shuriken strikes: it takes a share of the target's max health, armor or not (kamuiShare): a player hit in
     * the head (the top quarter of them, where it entered) is warped away entirely.
     */
    private void kamuiHit(Entity target) {
        if (!(target instanceof net.minecraft.world.entity.LivingEntity living) || !living.isAlive()) return;
        Vec3 pos = position().add(0, getBbHeight() / 2, 0);
        Vec3 move = getDeltaMovement();
        Vec3 entry = target.getBoundingBox().clip(pos.subtract(move.scale(2)), pos.add(move.scale(2))).orElse(pos);
        boolean head = entry.y >= target.getY() + target.getBbHeight() * 0.75;
        float amount = living.getMaxHealth() * kamuiShare(target, head);
        Entity owner = getOwner();
        net.minecraft.world.damagesource.DamageSource src = owner != null ? ModDamage.kamui(level(), owner) : ModDamage.jutsu(level(), this, null);
        float health = living.getHealth() + living.getAbsorptionAmount();
        if (amount >= health) {
            living.invulnerableTime = 0;
            living.hurt(src, Math.max(amount, health) * 1000f);         // through any armor: gone
        } else {
            living.invulnerableTime = 0;
            living.hurt(src, 0.01f);                                     // credit, knockback, the hurt flash
            float absorb = living.getAbsorptionAmount();
            float fromAbsorb = Math.min(absorb, amount);
            living.setAbsorptionAmount(absorb - fromAbsorb);
            living.setHealth(Math.max(0.5f, living.getHealth() - (amount - fromAbsorb)));
        }
        if (level() instanceof ServerLevel sl) {
            Vec3 c = target.getBoundingBox().getCenter();
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 60, 0.4, 0.6, 0.4, 0.15);
            sl.sendParticles(ParticleTypes.SQUID_INK, c.x, c.y, c.z, 20, 0.3, 0.4, 0.3, 0.05);
            sl.playSound(null, c.x, c.y, c.z, com.shinobiarts.registry.ModSounds.eyeSound("kamui"), getSoundSource(), 1.4f, 1.0f);
            if (head && target instanceof Player) {
                sl.playSound(null, c.x, c.y, c.z, SoundEvents.ENDERMAN_TELEPORT, getSoundSource(), 1.5f, 0.5f);
            }
        }
    }

    /** The creature the Water Shark bit (spared the second hit of its explosion). */
    private int bittenId = -1;

    /** How much an overcharge enlarged it (server side): its scale and every radius of its impact grow by this. */
    private float sizeMult = 1f;

    /** Takes the size of the jutsu being cast (an overcharge makes it bigger). */
    private void sizeFromCast() {
        sizeMult = JutsuUtil.size();
        setScale(1f);
    }

    /** Sets its size; an overcharged projectile is that much bigger again. */
    public void setScale(float scale) {
        setScaleRaw(scale * sizeMult);
    }

    private void setScaleRaw(float scale) {
        this.entityData.set(SCALE, Mth.clamp(scale, 0.1f, 60f));
        refreshDimensions();
    }

    @Override
    public net.minecraft.world.entity.EntityDimensions getDimensions(net.minecraft.world.entity.Pose pose) {
        return super.getDimensions(pose).scale(getScale());
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (SCALE.equals(key)) refreshDimensions();
    }

    public Kind getKind() {
        int i = this.entityData.get(KIND);
        return Kind.values()[Mth.clamp(i, 0, Kind.values().length - 1)];
    }

    public void setKind(Kind kind) {
        this.entityData.set(KIND, (byte) kind.ordinal());
    }

    private boolean isFire() {
        Kind k = getKind();
        return k == Kind.FIRE_BALL || k == Kind.FIRE_SMALL;
    }

    @Override
    protected float getGravity() {
        return 0.0f;
    }

    @Override
    public void tick() {
        if (!level().isClientSide && (getKind() == Kind.MAGATAMA || getKind() == Kind.KAMUI_SHURIKEN || getKind() == Kind.SUSANOO_ARROW) && tickCount > 3) home();
        if (getKind() == Kind.WATER_DRAGON) steerDragon();
        super.tick();
        if (level().isClientSide) {
            spawnTrail();
            return;
        }
        if (isRemoved()) return;
        if (isFire() && isInWaterOrBubble()) {
            ((ServerLevel) level()).sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY(), getZ(), 10, 0.2, 0.2, 0.2, 0.02);
            playSound(SoundEvents.FIRE_EXTINGUISH, 0.6f, 1.2f);
            discard();
        } else if (tickCount > MAX_LIFE) {
            discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        if (!super.canHitEntity(target)) return false;
        if (target.getId() == reflectedBy && tickCount < 10) return false;
        if (target instanceof net.minecraft.server.level.ServerPlayer sp) { // Kamui: jutsu pass through
            com.shinobiarts.ninja.NinjaData d = com.shinobiarts.ninja.NinjaData.get(sp);
            if (d != null && d.isIntangible(level().getGameTime())) return false;
        }
        Entity owner = getOwner();
        if (owner == null) return true;
        if (target == owner) return false;
        if (target instanceof SusanooEntity susanoo && susanoo.getOwnerId() == owner.getId()) return false; // its own Susanoo
        return !(target instanceof ShadowClone clone && owner.getUUID().equals(clone.getOwnerUUID()));
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;
        Entity target = result.getEntity();
        Kind kind = getKind();
        if (kind == Kind.KAMUI_SHURIKEN) {
            kamuiHit(target);
        } else if (kind == Kind.FIRE_SMALL) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.setSecondsOnFire(4);
        } else if (kind == Kind.WATER_SHARK) {
            // the shark bites: heavy damage, thrown along with it, and it eats some of a ninja's chakra (then it explodes)
            bittenId = target.getId();
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.clearFire();
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(1.3).add(0, 0.35, 0));
            if (target instanceof net.minecraft.server.level.ServerPlayer victim) {
                float eaten = com.shinobiarts.ninja.PlayerDataManager.drainChakra(victim, 15f);
                if (eaten > 0 && getOwner() instanceof net.minecraft.server.level.ServerPlayer caster) {
                    com.shinobiarts.ninja.NinjaData cd = com.shinobiarts.ninja.NinjaData.get(caster);
                    if (cd != null) {
                        cd.addChakra(eaten);
                        com.shinobiarts.network.ModNetwork.sync(caster);
                    }
                }
            }
        } else if (kind == Kind.WATER_BULLET) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            target.clearFire();
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(0.8).add(0, 0.2, 0));
        } else if (kind == Kind.SUSANOO_ARROW) {
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(1.2).add(0, 0.3, 0));
        } else if (kind == Kind.MAGATAMA) {
            if (target instanceof LivingEntity living) living.invulnerableTime = 0; // the three each count
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            JutsuUtil.push(target, getDeltaMovement().normalize().scale(0.5).add(0, 0.2, 0));
        } else if (kind == Kind.ICE_NEEDLE || kind == Kind.BONE_BULLET) {
            if (target instanceof LivingEntity living) living.invulnerableTime = 0; // a volley: every needle / bullet counts
            target.hurt(ModDamage.jutsu(level(), this, getOwner()), damage);
            if (kind == Kind.ICE_NEEDLE && target instanceof LivingEntity living) {
                living.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                living.setTicksFrozen(Math.min(living.getTicksRequiredToFreeze() + 40, living.getTicksFrozen() + 50)); // frost creeps in
            }
        }
        // FIRE_BALL, WATER_DRAGON, RASENGAN and RASENSHURIKEN deal area damage in impact().
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide && !isRemoved()) {
            impact(result.getLocation());
            discard();
        }
    }

    /**
     * The Rasenshuriken bursting into a sphere of wind blades: heavy damage all around, slowing and throwing everything
     * out. {@code already} (the creature it was slammed into, which took the hit already) is spared the second hit.
     */
    public static void rasenshurikenBurst(ServerLevel level, Entity direct, @javax.annotation.Nullable Entity owner, Vec3 pos,
                                          float damage, @javax.annotation.Nullable LivingEntity already) {
        // the core swells into a huge sphere of wind blades that keeps shredding everything inside it for a moment
        final double radius = 7.0;
        float size = JutsuUtil.size();
        com.shinobiarts.fx.Fx.at(level, com.shinobiarts.fx.Fx.Visual.RASEN_SPHERE, pos, (float) radius, 46);
        for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, radius)) {
            if (e != already) e.hurt(ModDamage.jutsu(level, direct, owner), damage);
            e.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 80, 3));
        }
        for (int k = 1; k <= 4; k++) {                      // caught in the sphere: cut again and again, then thrown out
            final int pulse = k;
            com.shinobiarts.util.Scheduler.later(8 * k, () -> JutsuUtil.withSize(size, () -> {
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, radius)) {
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, direct, owner), damage * 0.2f);
                    if (pulse == 4) {
                        Vec3 away = e.position().subtract(pos);
                        away = away.lengthSqr() < 1e-4 ? new Vec3(0, 1, 0) : away.normalize();
                        JutsuUtil.push(e, away.scale(1.6).add(0, 0.7, 0));
                    } else {
                        e.setDeltaMovement(e.getDeltaMovement().scale(0.2));
                        e.hurtMarked = true;
                    }
                }
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, pos.x, pos.y, pos.z, 20, radius * 0.5 * size, radius * 0.4 * size, radius * 0.5 * size, 0.0);
            }));
        }
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, pos.x, pos.y, pos.z, 2, 1.5, 1.0, 1.5, 0);
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, pos.x, pos.y, pos.z, 50, 3.5 * size, 2.5 * size, 3.5 * size, 0.0);
        level.sendParticles(WIND_DUST, pos.x, pos.y, pos.z, 160, 4.0 * size, 3.0 * size, 4.0 * size, 0.0);
        level.playSound(null, pos.x, pos.y, pos.z, com.shinobiarts.registry.ModSounds.RASENSHURIKEN_BURST.get(),
                net.minecraft.sounds.SoundSource.PLAYERS, 4.0f, 1.0f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, net.minecraft.sounds.SoundSource.PLAYERS, 1.6f, 0.7f);
    }

    private void impact(Vec3 pos) {
        JutsuUtil.withSize(sizeMult, () -> impactScaled(pos));        // an overcharged blast reaches as far as it looks
    }

    private void impactScaled(Vec3 pos) {
        ServerLevel level = (ServerLevel) level();
        Entity owner = getOwner();
        switch (getKind()) {
            case FIRE_BALL -> {
                float s = getScale(); // small tap: ~2 block blast, full charge: ~5.4 (times an overcharge)
                double radius = 1.5 + 1.5 * (s / sizeMult);                  // inRadius adds the overcharge back
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, radius)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.setSecondsOnFire(Math.round(3 + 2 * s));
                }
                double spread = 0.5 + 0.6 * s;
                level.sendParticles(s > 1.8f ? ParticleTypes.EXPLOSION_EMITTER : ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z,
                        s > 1.8f ? 1 : 2, 0.5, 0.5, 0.5, 0.0);
                level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, Math.round(40 + 45 * s), spread, spread * 0.8, spread, 0.06 + 0.02 * s);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, pos.x, pos.y, pos.z, Math.round(10 + 10 * s), spread, spread * 0.7, spread, 0.02);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.6f + 0.4f * s, 1.5f - 0.3f * s);
                if (JutsuUtil.griefing(level, owner)) placeFire(level, pos, Math.max(1, Math.min(12, Math.round(s * 1.3f))), Math.min(60, Math.round(4 + 4 * s)));
            }
            case FIRE_SMALL -> {
                level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 15, 0.3, 0.3, 0.3, 0.03);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIRECHARGE_USE, getSoundSource(), 0.5f, 1.4f);
                if (JutsuUtil.griefing(level, owner)) placeFire(level, pos, 0, 1);
            }
            case WATER_SHARK -> {
                // it goes off like TNT: the same blast (it only breaks blocks when jutsu griefing is on)
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 4.0)) {
                    if (e.getId() != bittenId) e.hurt(ModDamage.jutsu(level, this, owner), damage * 0.7f);
                }
                level.explode(this, pos.x, pos.y, pos.z, 4.0f,
                        JutsuUtil.griefing(level, owner) ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
            }
            case WATER_BULLET -> {
                level.sendParticles(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, 30, 0.4, 0.4, 0.4, 0.1);
                level.sendParticles(WATER_DUST, pos.x, pos.y, pos.z, 15, 0.3, 0.3, 0.3, 0.0);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_SPLASH, getSoundSource(), 0.7f, 1.5f);
            }
            case RASENGAN -> {
                Vec3 push = getDeltaMovement().lengthSqr() > 1e-4 ? getDeltaMovement().normalize() : Vec3.ZERO;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 2.2)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    JutsuUtil.push(e, push.scale(1.8).add(0, 0.5, 0));
                }
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.sendParticles(CHAKRA_DUST, pos.x, pos.y, pos.z, 50, 0.6, 0.6, 0.6, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 20, 0.5, 0.3, 0.5, 0.08);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.8f, 1.5f);
            }
            case RASENSHURIKEN -> rasenshurikenBurst(level, this, owner, pos, damage, null);
            case SUSANOO_ARROW -> {                              // the arrow bursts in a flash of its chakra
                float s = getScale();
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 1.5 + s)) {
                    e.invulnerableTime = 0;
                    e.hurt(ModDamage.jutsu(level, this, owner), damage * 0.5f);
                }
                level.sendParticles(colorDust(3.0f), pos.x, pos.y, pos.z, 80, s, s, s, 0.0);
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 2, 0.5, 0.5, 0.5, 0);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 1.3f, 1.3f);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BEACON_DEACTIVATE, getSoundSource(), 1.5f, 1.6f);
            }
            case KAMUI_SHURIKEN -> {
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, pos.x, pos.y, pos.z, 50, 1.0, 1.0, 1.0, 0.1);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENDERMAN_TELEPORT, getSoundSource(), 1.0f, 0.6f);
            }
            case MAGATAMA -> {
                level.sendParticles(colorDust(2.4f), pos.x, pos.y, pos.z, 30, 0.4, 0.4, 0.4, 0.0);
                level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, getSoundSource(), 0.6f, 1.5f);
            }
            case ICE_NEEDLE -> {
                level.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK,
                        net.minecraft.world.level.block.Blocks.PACKED_ICE.defaultBlockState()), pos.x, pos.y, pos.z, 6, 0.1, 0.1, 0.1, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, getSoundSource(), 0.25f, 1.8f);
            }
            case BONE_BULLET -> {
                level.sendParticles(new net.minecraft.core.particles.BlockParticleOption(ParticleTypes.BLOCK,
                        net.minecraft.world.level.block.Blocks.BONE_BLOCK.defaultBlockState()), pos.x, pos.y, pos.z, 8, 0.1, 0.1, 0.1, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BONE_BLOCK_BREAK, getSoundSource(), 0.6f, 1.4f);
            }
            case WATER_DRAGON -> {
                Vec3 push = getDeltaMovement().lengthSqr() > 1e-4 ? getDeltaMovement().normalize() : Vec3.ZERO;
                for (LivingEntity e : JutsuUtil.inRadius(level, owner, pos, 4.0)) {
                    e.hurt(ModDamage.jutsu(level, this, owner), damage);
                    e.clearFire();
                    Vec3 away = e.position().subtract(pos).multiply(1, 0, 1);
                    away = away.lengthSqr() < 1e-4 ? push : away.normalize();
                    JutsuUtil.push(e, away.scale(1.2).add(push.scale(0.8)).add(0, 0.5, 0));
                }
                level.sendParticles(ParticleTypes.SPLASH, pos.x, pos.y, pos.z, 150, 2.0, 1.2, 2.0, 0.3);
                level.sendParticles(WATER_DUST_BIG, pos.x, pos.y, pos.z, 60, 1.5, 1.0, 1.5, 0.0);
                level.sendParticles(ParticleTypes.CLOUD, pos.x, pos.y, pos.z, 20, 1.5, 0.5, 1.5, 0.05);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_SPLASH_HIGH_SPEED, getSoundSource(), 1.5f, 0.6f);
                level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_SPLASH, getSoundSource(), 1.5f, 0.8f);
            }
        }
    }

    private void placeFire(ServerLevel level, Vec3 pos, int radius, int attempts) {
        RandomSource r = level.getRandom();
        for (int i = 0; i < attempts; i++) {
            BlockPos bp = BlockPos.containing(pos.x + (radius == 0 ? 0 : r.nextInt(radius * 2 + 1) - radius),
                    pos.y + 0.5, pos.z + (radius == 0 ? 0 : r.nextInt(radius * 2 + 1) - radius));
            for (int k = 0; k < 3; k++, bp = bp.below()) {
                if (BaseFireBlock.canBePlacedAt(level, bp, Direction.UP)) {
                    level.setBlockAndUpdate(bp, BaseFireBlock.getState(level, bp));
                    break;
                }
            }
        }
    }

    private DustParticleOptions colorDust(float size) {
        int c = this.entityData.get(COLOR);
        return new DustParticleOptions(new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f), Math.max(0.3f, size));
    }

    /** Client-side visuals. */
    private void spawnTrail() {
        Level level = level();
        RandomSource r = this.random;
        double x = getX(), y = getY() + getBbHeight() / 2, z = getZ();
        switch (getKind()) {
            case FIRE_BALL -> {
                float s = getScale();
                double spread = 0.9 * s;
                for (int i = 0; i < Math.min(40, Math.round(3 + 4 * s)); i++) {
                    level.addParticle(ParticleTypes.FLAME, x + (r.nextDouble() - 0.5) * spread, y + (r.nextDouble() - 0.5) * spread,
                            z + (r.nextDouble() - 0.5) * spread, 0, 0.01, 0);
                }
                level.addParticle(ParticleTypes.LARGE_SMOKE, x, y, z, 0, 0.02, 0);
                if (r.nextInt(3) == 0) level.addParticle(ParticleTypes.LAVA, x, y, z, 0, 0, 0);
            }
            case FIRE_SMALL -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(ParticleTypes.FLAME, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                            z + (r.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.SMOKE, x, y, z, 0, 0, 0);
            }
            case WATER_BULLET -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(WATER_DUST, x + (r.nextDouble() - 0.5) * 0.3, y + (r.nextDouble() - 0.5) * 0.3,
                            z + (r.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.SPLASH, x, y, z, 0, 0, 0);
            }
            case RASENGAN -> {
                for (int i = 0; i < 6; i++) {
                    double a = (tickCount * 0.9 + i * Math.PI / 3);
                    level.addParticle(CHAKRA_DUST, x + Math.cos(a) * 0.3, y + Math.sin(a * 1.3) * 0.25, z + Math.sin(a) * 0.3, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.ENCHANTED_HIT, x, y, z, 0, 0, 0);
            }
            case RASENSHURIKEN -> {
                for (int i = 0; i < 4; i++) {
                    double a = tickCount * 1.2 + i * Math.PI / 2;
                    level.addParticle(WIND_DUST, x + Math.cos(a) * 1.2, y, z + Math.sin(a) * 1.2, 0, 0, 0);
                    level.addParticle(WIND_DUST, x + Math.cos(a) * 0.6, y, z + Math.sin(a) * 0.6, 0, 0, 0);
                }
                level.addParticle(CHAKRA_DUST, x, y, z, 0, 0, 0);
                if (r.nextInt(2) == 0) level.addParticle(ParticleTypes.SWEEP_ATTACK, x, y, z, 0, 0, 0);
            }
            case MAGATAMA -> { // a fat head with a curling tail, like the comma shape
                Vec3 step = getDeltaMovement();
                DustParticleOptions dust = colorDust(1.8f);
                for (int i = 0; i < 3; i++) level.addParticle(dust, x + (r.nextDouble() - 0.5) * 0.4, y + (r.nextDouble() - 0.5) * 0.4, z + (r.nextDouble() - 0.5) * 0.4, 0, 0, 0);
                for (int i = 1; i <= 4; i++) {
                    double a = tickCount * 0.9 + i * 0.6, f = i / 4.0;
                    level.addParticle(colorDust(1.3f - 0.2f * i), x - step.x * f + Math.cos(a) * 0.35 * f, y - step.y * f + Math.sin(a) * 0.35 * f,
                            z - step.z * f, 0, 0, 0);
                }
            }
            case ICE_NEEDLE, BONE_BULLET -> { // fast and small: a streak of dust along the whole step so they read as needles
                Vec3 step = getDeltaMovement();
                DustParticleOptions dust = getKind() == Kind.ICE_NEEDLE ? ICE_DUST : BONE_DUST;
                for (int i = 0; i < 4; i++) {
                    double f = i / 4.0;
                    level.addParticle(dust, x - step.x * f, y - step.y * f, z - step.z * f, 0, 0, 0);
                }
                if (getKind() == Kind.ICE_NEEDLE && r.nextInt(3) == 0) level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, 0, 0, 0);
            }
            case WATER_SHARK -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(ParticleTypes.SPLASH, x + (r.nextDouble() - 0.5) * 1.0, y + (r.nextDouble() - 0.5) * 0.8,
                            z + (r.nextDouble() - 0.5) * 1.0, 0, 0, 0);
                }
                level.addParticle(WATER_DUST, x, y, z, 0, 0, 0);
                if (r.nextInt(3) == 0) level.addParticle(ParticleTypes.BUBBLE_POP, x, y, z, 0, 0.02, 0);
            }
            case WATER_DRAGON -> {
                for (int i = 0; i < 3; i++) {
                    level.addParticle(WATER_DUST_BIG, x + (r.nextDouble() - 0.5) * 1.6, y + (r.nextDouble() - 0.5) * 1.6,
                            z + (r.nextDouble() - 0.5) * 1.6, 0, 0, 0);
                }
                for (int i = 0; i < 4; i++) {
                    level.addParticle(ParticleTypes.SPLASH, x + (r.nextDouble() - 0.5) * 1.2, y + (r.nextDouble() - 0.5) * 1.2,
                            z + (r.nextDouble() - 0.5) * 1.2, 0, 0, 0);
                }
                level.addParticle(ParticleTypes.CLOUD, x, y, z, 0, 0, 0);
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putByte("Kind", (byte) getKind().ordinal());
        tag.putFloat("Damage", damage);
        tag.putFloat("Scale", getScale());
        tag.putFloat("Size", sizeMult);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(KIND, tag.getByte("Kind"));
        this.damage = tag.getFloat("Damage");
        if (tag.contains("Size")) sizeMult = tag.getFloat("Size");
        if (tag.contains("Scale")) setScaleRaw(tag.getFloat("Scale"));
    }
}
