package com.shinobiarts.entity;

import com.shinobiarts.Config;
import com.shinobiarts.fx.Fx;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

/**
 * A soul brought back by Edo Tensei (Summoning: Impure World Reincarnation) in a body of ash and dust: it wears the
 * dead ninja's skin with cracks all over it and black whites to its eyes, and fights for whoever summoned it.
 * <p>
 * It comes up out of the ground in a coffin, the lid falls, and it steps out. It can't be killed: anything that
 * would kill it only breaks it apart, and the pieces drift back together in a few seconds. It's released (the soul
 * goes back and the body crumbles to dust) when its time runs out, when its summoner releases it (right-click it, or
 * cast the jutsu again), or when its summoner dies or leaves.
 */
public class EdoTensei extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(EdoTensei.class, EntityDataSerializers.OPTIONAL_UUID);
    /** Whose soul this is (for their skin); empty for a nameless soul. */
    private static final EntityDataAccessor<Optional<UUID>> SOUL = SynchedEntityData.defineId(EdoTensei.class, EntityDataSerializers.OPTIONAL_UUID);
    /** Ticks since it was summoned (counts up to FREE, then stops: the coffin's rise is drawn from it). */
    private static final EntityDataAccessor<Integer> RISEN = SynchedEntityData.defineId(EdoTensei.class, EntityDataSerializers.INT);
    /** Ticks left of putting itself back together (0 = whole). */
    private static final EntityDataAccessor<Integer> CRUMBLE = SynchedEntityData.defineId(EdoTensei.class, EntityDataSerializers.INT);

    /** The coffin comes up out of the ground over this many ticks... */
    public static final int RISE = 20;
    /** ...its lid falls at this tick... */
    public static final int LID = 34;
    /** ...and the soul steps out at this one. */
    public static final int FREE = 46;
    /** How long it takes to come back together after being broken apart. */
    public static final int REFORM = 60;

    private int life = 1800;
    private int ownerMissingTicks;
    private int leapCooldown = 60;

    public EdoTensei(EntityType<? extends EdoTensei> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.33)
                .add(Attributes.ATTACK_DAMAGE, 8.0)
                .add(Attributes.ARMOR, 6.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
        this.entityData.define(SOUL, Optional.empty());
        this.entityData.define(RISEN, 0);
        this.entityData.define(CRUMBLE, 0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.35, true));
        this.goalSelector.addGoal(2, new FollowSummonerGoal(this));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, 5, true, false,
                target -> !(target instanceof Creeper)));
    }

    // ---------------------------------------------------------------- who it is

    /** Sets up a freshly summoned soul: its summoner, whose soul it is, and how hard it hits (their level). */
    public void setup(Player owner, @Nullable UUID soul, String name, int soulLevel, int lifeTicks) {
        this.entityData.set(OWNER, Optional.of(owner.getUUID()));
        this.entityData.set(SOUL, Optional.ofNullable(soul));
        setCustomName(Component.literal(name));
        life = lifeTicks;
        double health = Config.f(Config.EDO_HEALTH);
        double damage = Config.f(Config.EDO_DAMAGE) * (1.0 + Math.min(100, Math.max(0, soulLevel)) / 100.0);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(health);
        getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(damage);
        setHealth((float) health);
    }

    @Nullable
    public UUID getOwnerUUID() {
        return this.entityData.get(OWNER).orElse(null);
    }

    @Nullable
    public UUID getSoulUUID() {
        return this.entityData.get(SOUL).orElse(null);
    }

    @Nullable
    public Player getOwner() {
        UUID id = getOwnerUUID();
        return id == null ? null : level().getPlayerByUUID(id);
    }

    /** Ticks since it was summoned, up to {@link #FREE}. */
    public int risen() {
        return this.entityData.get(RISEN);
    }

    public int crumble() {
        return this.entityData.get(CRUMBLE);
    }

    /** Still in its coffin, or still in pieces: it can't move or be hurt. */
    public boolean helpless() {
        return risen() < FREE || crumble() > 0;
    }

    private boolean isFriendly(Entity other) {
        UUID id = getOwnerUUID();
        if (id == null) return false;
        if (id.equals(other.getUUID())) return true;
        if (other instanceof EdoTensei edo) return id.equals(edo.getOwnerUUID());
        return other instanceof ShadowClone clone && id.equals(clone.getOwnerUUID());
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return isFriendly(other) || super.isAlliedTo(other);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return !isFriendly(target) && super.canAttack(target);
    }

    // ---------------------------------------------------------------- ticking

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || helpless();
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (crumble() > 0 && random.nextInt(2) == 0) {
                level().addParticle(ParticleTypes.ASH, getRandomX(0.6), getY() + random.nextDouble() * 1.8, getRandomZ(0.6), 0, 0.02, 0);
            }
            return;
        }
        if (isRemoved()) return;
        if (risen() < FREE) {
            this.entityData.set(RISEN, risen() + 1);
            if (risen() == FREE) playSound(SoundEvents.SAND_BREAK, 1.0f, 0.6f);
        }
        if (crumble() > 0) {
            this.entityData.set(CRUMBLE, crumble() - 1);
            if (crumble() == 0) {
                setHealth(getMaxHealth());
                playSound(SoundEvents.SAND_PLACE, 1.2f, 0.7f);
            }
        }
        if (--life <= 0) {
            release();
            return;
        }
        Player owner = getOwner();
        if (owner == null || !owner.isAlive()) {
            if (++ownerMissingTicks > 40) release();
            return;
        }
        ownerMissingTicks = 0;
        if (tickCount % 10 == 0) followSummonersFight(owner);
        if (tickCount % 20 == 0 && getHealth() < getMaxHealth()) heal(1.0f);  // the dust keeps filling the cracks back in
        leapAtTarget();
    }

    /** Fights whatever its summoner is fighting (or whoever's fighting its summoner). */
    private void followSummonersFight(Player owner) {
        LivingEntity hit = owner.getLastHurtMob();
        if (hit != null && hit.isAlive() && hit != this && !isFriendly(hit) && owner.tickCount - owner.getLastHurtMobTimestamp() < 100) {
            if (getTarget() != hit) setTarget(hit);
            return;
        }
        LivingEntity attacker = owner.getLastHurtByMob();
        if (attacker != null && attacker.isAlive() && attacker != this && !isFriendly(attacker) && getTarget() != attacker) {
            setTarget(attacker);
        }
    }

    /** A ninja's leap: closes in on a target a few blocks away in one bound. */
    private void leapAtTarget() {
        if (leapCooldown > 0) {
            leapCooldown--;
            return;
        }
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || !onGround() || helpless()) return;
        double dist = distanceTo(target);
        if (dist < 4 || dist > 14 || !hasLineOfSight(target)) return;
        Vec3 to = target.position().subtract(position());
        Vec3 flat = new Vec3(to.x, 0, to.z).normalize();
        setDeltaMovement(flat.scale(Math.min(1.6, dist * 0.13)).add(0, 0.42, 0));
        hasImpulse = true;
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.ASH, getX(), getY() + 0.2, getZ(), 12, 0.3, 0.1, 0.3, 0.02);
        }
        leapCooldown = 50 + random.nextInt(30);
    }

    // ---------------------------------------------------------------- it can't be killed

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(source, amount);  // /kill, the void
        if (helpless()) return false;
        if (source.getEntity() != null && isFriendly(source.getEntity())) return false;
        return super.hurt(source, amount);
    }

    /** What would kill it only breaks it apart; it puts itself back together (unless /kill or the void did it). */
    @Override
    public void die(DamageSource source) {
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || isRemoved()) {
            release();
            return;
        }
        setHealth(1.0f);
        this.entityData.set(CRUMBLE, REFORM);
        setTarget(null);
        getNavigation().stop();
        if (level() instanceof ServerLevel server) {
            Fx.on(server, Fx.Visual.EDO_CRUMBLE, this, null, getBbWidth(), REFORM);
            server.sendParticles(ParticleTypes.ASH, getX(), getY() + 1, getZ(), 60, 0.4, 0.8, 0.4, 0.05);
            server.playSound(null, getX(), getY(), getZ(), SoundEvents.SAND_BREAK, SoundSource.HOSTILE, 1.4f, 0.5f);
        }
    }

    /** The soul's released: it goes back, and the body crumbles to dust. */
    public void release() {
        if (isRemoved()) return;
        if (level() instanceof ServerLevel server) {
            Fx.at(server, Fx.Visual.EDO_RELEASE, position(), getBbHeight(), 50);
            server.sendParticles(ParticleTypes.ASH, getX(), getY() + 1, getZ(), 120, 0.35, 0.9, 0.35, 0.03);
            server.playSound(null, getX(), getY(), getZ(), SoundEvents.SAND_BREAK, SoundSource.HOSTILE, 1.5f, 0.4f);
            server.playSound(null, getX(), getY(), getZ(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 0.8f, 1.6f);
        }
        discard();
    }

    /** Its summoner right-clicks it: Kai, the release. */
    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.getUUID().equals(getOwnerUUID())) {
            if (!level().isClientSide) release();
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Nullable
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SAND_HIT;
    }

    @Nullable
    @Override
    protected SoundEvent getDeathSound() {
        return null;
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    // ---------------------------------------------------------------- save

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID owner = getOwnerUUID(), soul = getSoulUUID();
        if (owner != null) tag.putUUID("Owner", owner);
        if (soul != null) tag.putUUID("Soul", soul);
        tag.putInt("Life", life);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) this.entityData.set(OWNER, Optional.of(tag.getUUID("Owner")));
        if (tag.hasUUID("Soul")) this.entityData.set(SOUL, Optional.of(tag.getUUID("Soul")));
        if (tag.contains("Life")) life = tag.getInt("Life");
        this.entityData.set(RISEN, FREE);
    }

    // ---------------------------------------------------------------- following its summoner

    static class FollowSummonerGoal extends Goal {
        private final EdoTensei edo;
        @Nullable
        private Player owner;
        private int recalc;

        FollowSummonerGoal(EdoTensei edo) {
            this.edo = edo;
            setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = edo.getOwner();
            if (o == null || o.isSpectator() || edo.getTarget() != null || edo.distanceToSqr(o) < 25.0) return false;
            owner = o;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && edo.getTarget() == null && edo.distanceToSqr(owner) > 9.0;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            owner = null;
            edo.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (owner == null) return;
            edo.getLookControl().setLookAt(owner, 10.0f, edo.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (edo.distanceToSqr(owner) > 576.0) {
                    edo.teleportTo(owner.getX() + (edo.random.nextDouble() - 0.5) * 3, owner.getY(), owner.getZ() + (edo.random.nextDouble() - 0.5) * 3);
                    edo.getNavigation().stop();
                } else {
                    edo.getNavigation().moveTo(owner, 1.25);
                }
            }
        }
    }
}
