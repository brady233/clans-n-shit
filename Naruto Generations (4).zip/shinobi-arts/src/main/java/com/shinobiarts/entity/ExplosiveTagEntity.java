package com.shinobiarts.entity;

import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModEntities;
import com.shinobiarts.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** A thrown paper bomb: sticks to whatever block it hits and explodes after a short fuse. */
public class ExplosiveTagEntity extends ThrowableItemProjectile {
    private static final EntityDataAccessor<Boolean> STUCK = SynchedEntityData.defineId(ExplosiveTagEntity.class, EntityDataSerializers.BOOLEAN);
    private static final int FUSE = 40;
    private static final float POWER = 2.5f;

    private int fuse = FUSE;

    public ExplosiveTagEntity(EntityType<? extends ExplosiveTagEntity> type, Level level) {
        super(type, level);
    }

    public ExplosiveTagEntity(Level level, LivingEntity owner) {
        super(ModEntities.EXPLOSIVE_TAG.get(), owner, level);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STUCK, false);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.EXPLOSIVE_TAG.get();
    }

    public boolean isStuck() {
        return this.entityData.get(STUCK);
    }

    @Override
    public void tick() {
        if (isStuck()) {
            if (level().isClientSide) {
                if (tickCount % 2 == 0) level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.15, getZ(), 0, 0.04, 0);
                if (tickCount % 5 == 0) level().addParticle(ParticleTypes.FLAME, getX(), getY() + 0.15, getZ(), 0, 0.02, 0);
            } else if (--fuse <= 0) {
                detonate();
            } else if (fuse % 10 == 0) {
                playSound(SoundEvents.TNT_PRIMED, 0.4f, 1.8f);
            }
            return;
        }
        super.tick();
        if (!level().isClientSide && !isRemoved() && tickCount > 200) detonate();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        Vec3 loc = result.getLocation();
        Vec3 out = Vec3.atLowerCornerOf(result.getDirection().getNormal()).scale(0.08);
        setPos(loc.x + out.x, loc.y + out.y, loc.z + out.z);
        setDeltaMovement(Vec3.ZERO);
        setNoGravity(true);
        if (!level().isClientSide) {
            this.entityData.set(STUCK, true);
            playSound(SoundEvents.TRIPWIRE_ATTACH, 1.0f, 1.2f);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (!level().isClientSide) detonate();
    }

    private void detonate() {
        if (isRemoved()) return;
        Level.ExplosionInteraction mode = JutsuUtil.griefing(level(), getOwner())
                ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
        level().explode(this, getX(), getY(), getZ(), POWER, mode);
        discard();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Fuse", fuse);
        tag.putBoolean("Stuck", isStuck());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        fuse = tag.contains("Fuse") ? tag.getInt("Fuse") : FUSE;
        this.entityData.set(STUCK, tag.getBoolean("Stuck"));
    }
}
