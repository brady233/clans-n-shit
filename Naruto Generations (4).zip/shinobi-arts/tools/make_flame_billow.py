"""
Majestic Destroyer Flame's billows (textures/entity/jutsu/flame_billow.png): a 2x2 atlas of 64 px puffs of fire in the
Great Fireball's colours (white-yellow heart, orange body, red edges, mottled), with ragged tongues of flame licking out
of their edges so the wall of fire reads as fire, not smoke. Run: python3 tools/make_flame_billow.py
"""
import math
import os

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "entity", "jutsu", "flame_billow.png")


def noise(rng, n, octaves=4):
    out = np.zeros((n, n))
    for o in range(octaves):
        s = 4 * 2 ** o
        g = rng.random((s + 1, s + 1))
        img = Image.fromarray((g * 255).astype(np.uint8)).resize((n, n), Image.BICUBIC)
        out += np.asarray(img).astype(float) / 255 / (o + 1)
    return out / sum(1 / (o + 1) for o in range(octaves))


def puff(seed, n=64):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:n, 0:n] + 0.5
    cx = cy = n / 2
    dx, dy = (x - cx) / (n / 2), (y - cy) / (n / 2)
    r = np.hypot(dx, dy)
    a = np.arctan2(dy, dx)
    # the edge: a lumpy ball with many sharp tongues of flame, longer ones upwards
    edge = 0.70 + 0.05 * np.sin(a * 3 + seed)
    for k in range(9):
        f = rng.integers(5, 13)
        ph = rng.random() * math.pi * 2
        edge += 0.035 * np.maximum(0, np.sin(a * f + ph)) ** 3
    edge += 0.2 * np.maximum(0, -np.sin(a)) ** 2 * (0.55 + 0.45 * np.sin(a * 9 + seed))
    nz = noise(rng, n)
    edge = np.minimum(0.97, edge + (nz - 0.5) * 0.16)
    t = np.clip(r / edge, 0, 1.6)
    # colour: white-yellow heart, yellow, orange, red rim, mottled like the fireball
    mott = noise(rng, n, 5)
    heat = np.clip(1.0 - 0.85 * t + (mott - 0.5) * 0.7, 0, 1.2)
    stops = [(0.0, (150, 20, 5)), (0.25, (225, 70, 10)), (0.5, (255, 140, 20)), (0.75, (255, 205, 40)), (1.0, (255, 245, 170))]
    rgb = np.zeros((n, n, 3))
    for i in range(len(stops) - 1):
        (t0, c0), (t1, c1) = stops[i], stops[i + 1]
        m = (heat >= t0) & (heat < t1)
        f = ((heat - t0) / (t1 - t0))[m][:, None]
        rgb[m] = np.array(c0) * (1 - f) + np.array(c1) * f
    rgb[heat >= 1.0] = stops[-1][1]
    alpha = np.clip((1.0 - t) / 0.18, 0, 1) ** 0.8 * 255
    return np.dstack([rgb, alpha])


def main():
    atlas = np.zeros((128, 128, 4))
    for i in range(4):
        atlas[(i // 2) * 64:(i // 2 + 1) * 64, (i % 2) * 64:(i % 2 + 1) * 64] = puff(11 + i * 7)
    Image.fromarray(np.clip(atlas, 0, 255).astype(np.uint8), "RGBA").save(OUT)


if __name__ == "__main__":
    main()
