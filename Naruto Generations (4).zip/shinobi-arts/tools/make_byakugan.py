"""
The Byakugan's jutsu models and textures (drawn by client/fx/FxByakugan.java):

  assets/shinobiarts/meshes/chakra_palm.bin              a palm of chakra (Gentle Fist, 64 Palms, Air Palm): an open hand,
                                                         fingers along +y, the palm facing +z, 1 block tall
  textures/entity/byakugan/trigrams.png                  the Eight Trigrams field drawn on the ground under 64 Palms
  textures/entity/byakugan/swirl.png                     streaks of spinning chakra (Palm Rotation's dome)

Run: python3 tools/make_byakugan.py   (needs numpy and Pillow)
"""
import math
import os
import struct
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "susanoo"))
import mesh  # noqa: E402
from mesh import Mesh, V, circle, superellipse, unit  # noqa: E402

ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")


def out(*parts):
    p = os.path.join(ASSETS, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def palm():
    """An open hand, fingers a little spread and curled toward the palm side (+z)."""
    m = Mesh("chakra_palm")
    m.bone("hand")
    m.blob("hand", "c", (0, 5.2, 0), (9.2, 10.5, 3.4), e=(0.7, 0.9), seg=(18, 12))            # the palm
    m.blob("hand", "c", (2.3, 3.0, 0.5), (3.8, 4.8, 3.0), e=(1, 1), seg=(12, 8))              # the thumb's mound
    m.sweep("hand", "c", [V(0, 1.5, 0), V(0, -1.5, -0.2), V(0, -4.0, -0.4)], (5.8, 3.2), profile=superellipse(14, 2.2), n=3)  # wrist
    fingers = ((-3.3, 6.0, -10), (-1.1, 7.2, -3), (1.1, 6.9, 3), (3.2, 5.6, 10))
    for x, L, spread in fingers:
        a = math.radians(spread)
        base = V(x, 9.6, 0.2)
        d = V(math.sin(a), math.cos(a), 0)
        pts = [base, base + d * L * 0.45 + V(0, 0, 0.35), base + d * L * 0.8 + V(0, 0, 0.9), base + d * L + V(0, 0, 1.5)]
        m.sweep("hand", "c", pts, lambda t: (2.3 - 0.5 * t, 2.1 - 0.45 * t), profile=circle(10), n=3)
    tb = V(4.0, 2.6, 0.8)
    pts = [tb, tb + V(2.0, 1.8, 0.7), tb + V(3.4, 3.8, 1.3), tb + V(4.0, 5.6, 1.8)]
    m.sweep("hand", "c", pts, lambda t: (2.8 - 0.8 * t, 2.4 - 0.6 * t), profile=circle(10), n=3)
    return m


def write_mesh(path, groups):
    with open(path, "wb") as f:
        f.write(struct.pack(">i", len(groups)))
        for tex, opacity, tris in groups:
            f.write(struct.pack(">ifi", tex, opacity, len(tris)))
            for P, UV, N in tris:
                for k in range(3):
                    f.write(struct.pack(">8f", *P[k], *UV[k], *N[k]))


def mesh_tris(m, scale):
    data = m.export(decimals=4)
    tris = []
    for p in data["pieces"]:
        pos = np.asarray(p["pos"]).reshape(-1, 3) * scale
        nrm = np.asarray(p["nrm"]).reshape(-1, 3)
        uv = np.asarray(p["uv"]).reshape(-1, 2)
        idx = np.asarray(p["idx"]).reshape(-1, 3)
        for a, b, c in idx:
            tris.append(((pos[a], pos[b], pos[c]), (uv[a], uv[b], uv[c]), (nrm[a], nrm[b], nrm[c])))
    return tris


def trigrams(size=512):
    """The Eight Trigrams field: rings, the eight trigrams round a yin-yang, radial lines, all white on clear."""
    S = size * 2
    img = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(img)
    c = S / 2

    def ring(r, w):
        d.ellipse([c - r, c - r, c + r, c + r], outline=255, width=int(w))

    ring(S * 0.49, S * 0.012)
    ring(S * 0.455, S * 0.005)
    ring(S * 0.30, S * 0.008)
    ring(S * 0.17, S * 0.008)
    # radial lines between the trigrams, and the outer ring of ticks
    for k in range(8):
        a = math.radians(k * 45 + 22.5)
        d.line([(c + math.cos(a) * S * 0.17, c + math.sin(a) * S * 0.17), (c + math.cos(a) * S * 0.455, c + math.sin(a) * S * 0.455)],
               fill=255, width=int(S * 0.005))
    for k in range(64):
        a = math.radians(k * 360 / 64)
        r0, r1 = S * 0.462, S * 0.483
        d.line([(c + math.cos(a) * r0, c + math.sin(a) * r0), (c + math.cos(a) * r1, c + math.sin(a) * r1)], fill=255, width=int(S * 0.004))
    # the eight trigrams (King Wen order), three bars each, solid (yang) or broken (yin), innermost line first
    order = ["111", "011", "101", "001", "110", "010", "100", "000"]
    for k, bits in enumerate(order):
        a = math.radians(k * 45 - 90)
        u = np.array([math.cos(a), math.sin(a)])
        t = np.array([-math.sin(a), math.cos(a)])
        for j, bit in enumerate(bits):
            r = S * (0.20 + 0.04 * j)
            half = S * (0.065 + 0.012 * j)
            th = S * 0.022
            segs = [(-half, half)] if bit == "1" else [(-half, -half * 0.18), (half * 0.18, half)]
            for s0, s1 in segs:
                p = [u * r + t * s0 - u * th / 2, u * r + t * s1 - u * th / 2, u * r + t * s1 + u * th / 2, u * r + t * s0 + u * th / 2]
                d.polygon([(c + q[0], c + q[1]) for q in p], fill=255)
        # a small ring and character-like mark out by the edge
        r = S * 0.38
        q = (c + u[0] * r, c + u[1] * r)
        d.ellipse([q[0] - S * 0.028, q[1] - S * 0.028, q[0] + S * 0.028, q[1] + S * 0.028], outline=255, width=int(S * 0.005))
        d.line([q[0] - t[0] * S * 0.016, q[1] - t[1] * S * 0.016, q[0] + t[0] * S * 0.016, q[1] + t[1] * S * 0.016], fill=255, width=int(S * 0.005))
    # yin-yang
    R = S * 0.12
    d.ellipse([c - R, c - R, c + R, c + R], outline=255, width=int(S * 0.008))
    d.pieslice([c - R, c - R, c + R, c + R], 90, 270, fill=255)
    d.ellipse([c - R / 2, c - R, c + R / 2, c], fill=255)
    d.ellipse([c - R / 2, c, c + R / 2, c + R], fill=0)
    d.ellipse([c - R / 2, c, c + R / 2, c + R], outline=0)
    d.ellipse([c - R * 0.13, c - R * 0.63, c + R * 0.13, c - R * 0.37], fill=0)
    d.ellipse([c - R * 0.13, c + R * 0.37, c + R * 0.13, c + R * 0.63], fill=255)
    d.ellipse([c - R, c - R, c + R, c + R], outline=255, width=int(S * 0.008))
    img = img.resize((size, size), Image.LANCZOS)
    glow = img.filter(ImageFilter.GaussianBlur(size * 0.012))
    a = np.maximum(np.asarray(img, float), np.asarray(glow, float) * 0.8)
    rgba = np.zeros((size, size, 4), np.uint8)
    rgba[..., :3] = 255
    rgba[..., 3] = np.clip(a, 0, 255).astype(np.uint8)
    return Image.fromarray(rgba, "RGBA")


def swirl(w=128, h=64):
    """Streaks of chakra for the spinning dome: tiles across, fading at top and bottom."""
    rng = np.random.default_rng(3)
    img = np.zeros((h, w))
    yy, xx = np.mgrid[0:h, 0:w]
    for k in range(26):
        y0 = rng.uniform(0, h)
        slope = rng.uniform(0.25, 0.5)
        width = rng.uniform(1.0, 3.2)
        bright = rng.uniform(0.4, 1.0)
        for ox in (-w, 0, w):
            yline = y0 + (xx - ox) * slope * h / w
            for oy in (-h, 0, h):
                dd = np.abs(yy - (yline + oy))
                img = np.maximum(img, bright * np.clip(1 - dd / width, 0, 1) * (0.6 + 0.4 * np.sin((xx + k * 9) / w * 2 * math.pi * 2)))
    img = np.clip(img * 1.1, 0, 1)
    rgba = np.zeros((h, w, 4), np.uint8)
    rgba[..., :3] = 255
    rgba[..., 3] = (img * 255).astype(np.uint8)
    return Image.fromarray(rgba, "RGBA")


def main():
    mesh.SPAN_DETAIL, mesh.BLOB_DETAIL, mesh.RING_DETAIL = 0.7, 0.8, 0.8
    tris = mesh_tris(palm(), 1 / 16)
    write_mesh(out("meshes", "chakra_palm.bin"), [(0, 1.0, tris)])
    trigrams().save(out("textures", "entity", "byakugan", "trigrams.png"))
    swirl().save(out("textures", "entity", "byakugan", "swirl.png"))
    print("palm", len(tris), "triangles")


if __name__ == "__main__":
    main()
